angular.module('AstraZeneca.App')
    .controller('SyncController', function ($scope, $state, $rootScope, $filter, UtilsService,
        IonicLoadingService, $stateParams, ApplicationService, SmartStoreSyncService, ForceClientService) {

        $scope.activeBoxClass = "col col-25 tab-item active";
        $scope.inactiveBoxClass = "col col-25 tab-item";
        $scope.activeBtnClass = "button button-clear button-positive";
        $scope.inactiveBtnClass = "button button-clear button-light";

        $scope.showTotal = true;
        $scope.totalBoxClass = $scope.activeBoxClass;
        $scope.totalClass = $scope.activeBtnClass;

        $scope.showSynced = false;
        $scope.syncBoxClass = $scope.inactiveBoxClass;
        $scope.syncClass = $scope.inactiveBtnClass;

        $scope.showFailed = false;
        $scope.failedBoxClass = $scope.inactiveBoxClass;
        $scope.failedClass = $scope.inactiveBtnClass;

        $scope.isSyncing = false;
        $scope.syncProgress = 0;


        $scope.displayTotal = function () {
            $scope.showTotal = true;
            $scope.totalBoxClass = $scope.activeBoxClass;
            $scope.totalClass = $scope.activeBtnClass;

            $scope.showSynced = false;
            $scope.syncBoxClass = $scope.inactiveBoxClass;
            $scope.syncClass = $scope.inactiveBtnClass;

            $scope.showFailed = false;
            $scope.failedBoxClass = $scope.inactiveBoxClass;
            $scope.failedClass = $scope.inactiveBtnClass;

        }
        $scope.displaySynced = function () {
            $scope.showTotal = false;
            $scope.totalBoxClass = $scope.inactiveBoxClass;
            $scope.totalClass = $scope.inactiveBtnClass;

            $scope.showSynced = true;
            $scope.syncBoxClass = $scope.activeBoxClass;
            $scope.syncClass = $scope.activeBtnClass;

            $scope.showFailed = false;
            $scope.failedBoxClass = $scope.inactiveBoxClass;
            $scope.failedClass = $scope.inactiveBtnClass;

        }
        $scope.displayFailed = function () {
            $scope.showTotal = false;
            $scope.totalBoxClass = $scope.inactiveBoxClass;
            $scope.totalClass = $scope.inactiveBtnClass;

            $scope.showSynced = false;
            $scope.syncBoxClass = $scope.inactiveBoxClass;
            $scope.syncClass = $scope.inactiveBtnClass;

            $scope.showFailed = true;
            $scope.failedBoxClass = $scope.activeBoxClass;
            $scope.failedClass = $scope.activeBtnClass;
        }

        $scope.syncResults = {
            application: null,
            total: 0,
            processed: 0,
            failed: 0,
            results: []
        };

        $scope.allResults = [];
        $scope.syncedResults = [];
        $scope.failedResults = [];
        $scope.filteredNodeId = [];

        $scope.resetSyncResults = function () {
            $scope.syncResults = {
                application: null,
                total: 0,
                processed: 0,
                failed: 0,
                results: []
            };

            $scope.allResults = [];
            $scope.syncedResults = [];
            $scope.failedResults = [];
            $scope.filteredNodeId = [];
        };

        $scope.filterResult = function (result) {
            if (result == null) return;

            try {
                if ($scope.filteredNodeId.indexOf(result.Id) != -1) {
                    return;
                }

                if (result.status == 1) {
                    $scope.syncedResults.unshift(result);
                    $scope.syncResults.processed++;
                } else if (result.status == -1) {
                    result.isSyncing = false;
                    $scope.failedResults.unshift(result);
                }

                $scope.allResults.unshift(result);
                $scope.filteredNodeId.push(result.Id);

            } catch (e) {
                console.log(e);
            }
        }

        $scope.removeFailedResult = function (result) {
            if (result == null) return;

            try {
                if ($scope.filteredNodeId.indexOf(result.Id) == -1) {
                    return;
                }

                if (result.status == 1) {
                    $scope.syncedResults.unshift(result);
                    $scope.syncResults.processed = $scope.syncedResults.length;
                }

                for (var i = 0; i < $scope.failedResults.length; i++) {
                    //Remove the item from array
                    if ($scope.failedResults[i].Id == result.Id) {
                        $scope.failedResults.splice(i, 1);
                    }
                }

                $scope.syncResults.failed = $scope.failedResults.length;

            } catch (e) {
                console.log(e);
            }
        }

        $scope.startSync = function () {

            if ($rootScope.online) {
                $scope.syncProgress = 0;
                $scope.isSyncing = true;
                $scope.resetSyncResults();
                try {
                    //Retrieve the latest language information of current user
                    ForceClientService.getUserLanguage().then(function (language) {
                        //Sync application using the latest language information
                        SmartStoreSyncService.startSync(language).then(function (result) {

                            if (result.application != null) {
                                ApplicationService.setApplication(result.application);
                            }

                            $scope.syncResults = result;

                            $scope.isSyncing = false;

                            angular.forEach(result.results, function (item) {
                                $scope.filterResult(item);
                            });

                            //Update the synced status to application
                            ApplicationService.updateApplicationUsingSyncResults(result.results);

                            console.log("Sync now finshed");

                        }, function (error) {
                            $scope.isSyncing = false;
                        }, function (progress) {

                            //Display Sync progress
                            $scope.syncResults = progress;
                            var doneCount = progress.results.length;
                            $scope.syncProgress = Math.floor(doneCount * 100 / progress.total);

                            angular.forEach(progress.results, function (item) {
                                $scope.filterResult(item);
                            });

                        });
                    }, function (error) {
                        UtilsService.dialog(
                            $filter('translate')('cl.global.lb_message'),
                            $filter('translate')('cl.home.msg_failedToGetUserInfo'),
                            $filter('translate')('cl.global.btn_ok')
                        );
                        $scope.isSyncing = false;
                    });
                } catch (e) {
                    console.log("startSync" + e);
                    $scope.isSyncing = false;
                }

            } else {
                try {
                    console.log($filter('translate')('cl.global.lb_message') + "Offline Mode");
                    UtilsService.dialog(
                        $filter('translate')('cl.global.lb_message'),
                        $filter('translate')('cl.home.msg_youDeviceIsOffLineForSynchronization'),
                        $filter('translate')('cl.global.btn_ok')
                    );
                } catch (e) {
                    console.log(e);
                }

            }

        };

        $scope.startSyncSingleNode = function (nodeId) {

            if ($rootScope.online) {
                IonicLoadingService.show();

                try {
                    SmartStoreSyncService.startSyncHtmlContent($scope.syncResults.application, nodeId).then(function (result) {
                        if (result.status != -1) {
                            $scope.removeFailedResult(result);
                        }
                        IonicLoadingService.hide();
                    }, function (error) {
                        IonicLoadingService.hide();
                        //UtilsService.showAlert("Sync Error", error.message);

                        UtilsService.dialog(
                            $filter('translate')('cl.global.lb_message'),
                            error.message,
                            $filter('translate')('cl.global.btn_ok')
                        );
                    }, function (progress) {});
                } catch (e) {
                    console.log("startSyncSingleNode" + e);
                    IonicLoadingService.hide();
                }
            } else {
                UtilsService.dialog(
                    $filter('translate')('cl.global.lb_message'),
                    $filter('translate')('cl.home.msg_youDeviceIsOffLineForSynchronization'),
                    $filter('translate')('cl.global.btn_ok')
                );
            }

        };

        $scope.getLeftNodePath = function (nodeId) {
            //return "Node Title";
            console.log("Application ID:" + $scope.syncResults.application.Id + ";NodeId：" + nodeId);
            return ApplicationService.readNodePath($scope.syncResults.application, nodeId);
        };

        $scope.goToContent = function (nodeId) {
            $state.go("app.content", {
                contentId: nodeId,
                from: "app.sync"
            });
            //HtmlContentDisplayService.loadHtmlContent(nodeId, false);
        };

        $scope.gotoSearch = function () {
            $state.go("app.search");
        };

        $scope.goToFAQ = function () {

            var faqPaths = ApplicationService.getApplication().FAQ;
            //faqPaths = "a2Wc0000000ekc5EAA-a2Wc0000000eOyxEAE-a2Yc0000000l3ULEAY";
            console.log("FAQ Path:" + faqPaths);
            if (faqPaths != null) {

                var faqIds = faqPaths.split('-');
                var lastId = faqIds[faqIds.length - 1];

                if (ApplicationService.isLeftNodeById(lastId)) {
                    $state.go("app.content", {
                        contentId: lastId,
                        from: "app.sync"
                    });

                } else {
                    $state.go("app.faq", {
                        from: "app.sync"
                    });
                    /*if (ApplicationService.setCurrentSubChapterById(faqIds[faqIds.length - 1])) {
                        $state.go("app.faq");
                    } else {
                        UtilsService.dialog(
                            $filter('translate')('cl.global.lb_message'),
                            $filter('translate')('cl.home.msg_faqNotFound'),
                            $filter('translate')('cl.global.btn_ok')
                        );
                    }*/
                }

            }

        };
    });
