angular.module('AstraZeneca.App')
    .controller('SearchController', function ($scope, $state, $rootScope, $stateParams, ApplicationService, HtmlContentModel, HtmlContentDisplayService) {

        $scope.searchContent = "";
        $scope.searchResults = [];
        $scope.displayResults = [];
        $scope.showSearchContent = false;

        $scope.decorationResults = function (decorationFunc) {
            for (var i = 0; i < $scope.searchResults.length; i++) {
                decorationFunc($scope.searchResults[i]);
            }
        };

        $scope.forceWindowScroll = function () {
            //console.log("WindowScroll");
            window.scrollTo(0, 0);
        };

        $scope.doSearch = function (lookupText) {
            //console.log("doSearch:" + lookupText + ":" + lookupText.length);

            //Reset search results
            $scope.searchResults = [];
            $scope.displayResults = [];
            
            if (lookupText.length > 1) {

                var wrapperLookupText = lookupText + "*";

                HtmlContentModel.searchByContent(wrapperLookupText).then(function (result) {
                    $scope.searchResults = result;
                    $scope.decorationResults($scope.addPathToResult);
                    $scope.showSearchContent = true;
                }, function (error) {
                    alert(error);
                }, function (progress) {

                });
            } 
        };

        $scope.addPathToResult = function (result) {
            //return "Node Title";
            /*console.log("NodeId：" + result.Id);
            console.log("updated：" + result.updated);
            console.log("lastSyncDown：" + result.lastSyncDown);*/
            try {
                //If the result node can not be found in current application hierarchy
                result.path = ApplicationService.generateLeftNodeTitle(result.Id);
                if (result.path) {
                    //result.display = true;
                    result.name = result.path.slice(result.path.lastIndexOf('/') + 1);
                    result.color = ApplicationService.findChapterByNodeId(result.Id).Main_Colour;
                    
                    $scope.displayResults.push(result);
                } 
            } catch (e) {
                console.log("Exception：" + e);
            }
        };

        $scope.goToContent = function (nodeId) {

            //HtmlContentDisplayService.loadHtmlContent(nodeId, true);
            $state.go("app.content", {
                contentId: nodeId,
                from: $state.current.name
            });
        };

        $scope.close = function () {
            $state.go("app.home");
        };

    });
