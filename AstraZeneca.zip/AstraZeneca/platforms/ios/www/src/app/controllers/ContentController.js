angular.module('AstraZeneca.App')
    .controller('ContentController', function ($scope, $state, $rootScope, $stateParams, 
                                                IonicLoadingService, ApplicationService, UtilsService,
                                                HtmlContentService, HtmlContentModel, SmartStoreSyncService) {

        $scope.contentId = $stateParams.contentId;
        $scope.from = $stateParams.from;
        $scope.application = ApplicationService.getApplication();

        $scope.title = ApplicationService.generateLeftNodeTitle($scope.contentId);

        console.log($scope.title);

        /*
         * Load the content from corresponding html file, file name is "[Id].html"
         * @param retry When retry is true, the function will try to sync the html file again if failed to load.
         */
        $scope.loadContent = function (retry) {

            try {
                var contentURL = cordova.file.documentsDirectory + $scope.contentId;
                var contentFileName = $scope.contentId + ".html";

                //$scope.contentUrl = contentURL + "/" + contentFileName;
                
                //read the corresponding html file
                HtmlContentService.readHtmlContent(contentFileName, contentURL).then(function (success) {
                    $scope.contentUrl = contentURL + "/" + contentFileName;

                    //update the statistics data
                    HtmlContentModel.fetchByContentId($scope.contentId).then(function (result) {

                        if (result) {
                            result.updated = 0;

                            //console.log("update Html content obj:" + JSON.stringify(obj));
                            HtmlContentModel.upsert(result).then(function (success) {
                                ApplicationService.updateUpdatedFlag($scope.application, $scope.contentId, 0);
                            }, function (error) {
                                console.log("updateByExtternalId error:" + JSON.stringify(error));
                            });
                        }

                    }, function (error) {
                        console.log("fetchByContentId error:" + JSON.stringify(error));
                    });
                }, function (error) {

                    console.log("readHtmlContent error:" + JSON.stringify(error));
                    if ($rootScope.online && retry) {
                        IonicLoadingService.show();
                        try {
                            SmartStoreSyncService.startSyncHtmlContent(null, $scope.contentId).then(function (result) {
                                IonicLoadingService.hide();
                                if (result.status == 1) {
                                    $scope.loadContent(false);
                                }
                            }, function (error) {
                                IonicLoadingService.hide();
                                UtilsService.showAlert("Sync Error", error.message);
                            }, function (progress) {});
                        } catch (e) {
                            console.log("startSyncSingleNode" + e);
                        }
                    }

                });
            } catch (err) {
                console.log("loadContent exception:" + err);
            }

        };

        $scope.loadContent(true);

        $scope.close = function () {
            $state.go($scope.from);
        };

        $scope.gotoSearch = function () {
            $state.go("app.search");
        };
    });
