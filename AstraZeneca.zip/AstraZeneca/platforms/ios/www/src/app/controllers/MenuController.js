angular.module('AstraZeneca.App')
    .controller('MenuController', function ($scope, $state, $ionicActionSheet, $ionicModal, $rootScope, $filter, LoginService, UtilsService,
        ApplicationModel, ApplicationService, HtmlContentModel, HtmlContentDisplayService, $ionicSideMenuDelegate) {

        $scope.appName = "EI SOP User Portal";
        $scope.lastSync = "";
        $scope.hierarchiesCount = 0;
        $scope.contentCount = 0;
        $scope.currentState = "app.home";

        $scope.application = ApplicationService.getApplication();
        $scope.sitemap = ApplicationService.getContents();

        //$scope.loadApplication();
        // Triggered on logout menu click
        $scope.logout = function () {

            console.log("Logout");
            // Show the action sheet
            var hideSheet = $ionicActionSheet.show({
                buttons: [
                    {
                        text: 'Logout'
                    }
                ],
                titleText: 'Are you sure?',
                cancelText: 'Cancel',
                cancel: function () {
                    // cancel logout action
                },
                buttonClicked: function (index) {
                    // do logout action
                    LoginService.logout();
                    cordova.require("com.salesforce.plugin.sfaccountmanager").logout();
                    return true;
                }
            });

        };


        //Sitemap Function
        $ionicModal.fromTemplateUrl('src/app/templates/template-sitemap.html', {
            scope: $scope
        }).then(function (modal) {
            $scope.sitemapModel = modal;
        });

        //Hide sitemap model
        $scope.hideSitemap = function () {
            console.log("hideSitemap");
            $scope.sitemapModel.hide();
        };

        // Show sitemap model
        $scope.showSitemap = function () {
            console.log("showSitemap");

            $scope.currentState = $state.current.name;
            $scope.application = ApplicationService.getApplication();
            $scope.sitemap = ApplicationService.getContents();

            $scope.sitemapModel.show();
        };


        //App Version
        $ionicModal.fromTemplateUrl('src/app/templates/template-version.html', {
            scope: $scope
        }).then(function (modal) {
            $scope.appVersionModel = modal;
        });

        //Hide sitemap model
        $scope.hideAppVersion = function () {
            $scope.appVersionModel.hide();
        };

        // Show sitemap model
        $scope.showAppVersion = function () {

            $scope.application = ApplicationService.getApplication();

            if (UtilsService.isMobileDevice()) {
                try {
                    $scope.appName = $scope.application.Name;
                    //Retrieve the last sync datetime
                    HtmlContentModel.fetchLastSyncDown().then(function (result) {
                        //console.log("fetchLastSyncDown NUmber:" + new Number(result));
                        var syncDate = new Date(new Number(result));
                        //console.log("fetchLastSyncDown:" + syncDate);
                        $scope.lastSync = syncDate.toISOString().slice(0, 19).replace('T', ' ');
                    }, function (error) {
                        console.log(error);
                    });

                    $scope.hierarchiesCount = ApplicationService.countHierarchyNodes($scope.application);

                    $scope.contentCount = ApplicationService.countLeftNodes($scope.application);
                } catch (e) {
                    console.error("showAppVersion Exception:" + e);
                }
                $scope.appName = $scope.application.Name;
            }


            $scope.appVersionModel.show();
        };


        //Sitemap Node Controller
        /*$scope.getLeftNodePath = function (nodeId) {
            //return "Node Title";
            console.log("Application ID:" + $scope.syncResults.application.Id + ";NodeId：" + nodeId);
            return ApplicationService.readNodePath($scope.syncResults.application, nodeId);
        };*/

        $scope.goToContent = function (nodeId) {
            try {
                if (ApplicationService.isLeftNodeById(nodeId)) {

                    console.log("Show content:" + nodeId);
                    $state.go("app.content", {
                        contentId: nodeId,
                        from: $scope.currentState
                    });
                    //HtmlContentDisplayService.loadHtmlContent(nodeId, true);
                }
            } catch (e) {
                console.error("goToContent Exception:" + e);
            }
        };

        $scope.isLeftNode = function (nodeId) {
            return ApplicationService.isLeftNode(nodeId);
        };

        $scope.goToFAQ = function () {

            console.log("State:" + JSON.stringify($state.current.name));

            var faqPaths = $scope.application.FAQ;
            //faqPaths = "a2Wc0000000ekc5EAA-a2Wc0000000eOyxEAE-a2Yc0000000l3ULEAY";
            console.log("FAQ Path:" + faqPaths);
            if (faqPaths != null) {

                var faqIds = faqPaths.split('-');
                var lastId = faqIds[faqIds.length - 1];

                if (ApplicationService.isLeftNodeById(lastId)) {
                    $state.go("app.content", {
                        contentId: lastId,
                        from: $state.current.name
                    });

                    $ionicSideMenuDelegate.toggleLeft();

                } else {
                    $state.go("app.faq", {
                        from: $state.current.name
                    });

                    $ionicSideMenuDelegate.toggleLeft();
                }

            }

        };

        $scope.goToHome = function () {
            try {
                //reload the home page
                ApplicationService.setReloadFlag(1);
                $state.go("app.home", {}, {
                    reload: true,
                    inherit: false,
                    notify: true
                });
            } catch (e) {
                console.error("goToHome Exception:" + e);
            }
        };
    });
