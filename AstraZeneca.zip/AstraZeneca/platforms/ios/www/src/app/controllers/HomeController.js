angular.module('AstraZeneca.App')
    .controller('HomeController', function ($scope, $state, $rootScope, $filter, $stateParams, ApplicationModel, UtilsService, ApplicationService, ImageCacheService, ForceClientService) {

        $rootScope.currentMainPage = "app.home";

        $scope.application = ApplicationService.getApplication();
        $scope.chapters = ApplicationService.getContents();

        $scope.getBackgroundColor = function (basicColor, isCollapsed) {

            function factorColor(color, factor) {
                var redColor = parseInt(color.slice(0, 2), 16);
                redColor = Math.floor(redColor * factor);

                var newRedColor = redColor.toString(16).length == 2 ? redColor.toString(16) : "0" + redColor.toString(16);

                var greenColor = parseInt(color.slice(2, 4), 16);
                greenColor = Math.floor(greenColor * factor);
                var newGreenColor = greenColor.toString(16).length == 2 ? greenColor.toString(16) : "0" + greenColor.toString(16);

                var blueColor = parseInt(color.slice(4, 6), 16);
                blueColor = Math.floor(blueColor * factor);
                var newBlueColor = blueColor.toString(16).length == 2 ? blueColor.toString(16) : "0" + blueColor.toString(16);

                return newRedColor + newGreenColor + newBlueColor;
            }


            if (isCollapsed) {
                console.log("basicColor=" + basicColor);
                var newColor = factorColor(basicColor.slice(1), 0.5);
                console.log("newColor=" + newColor);
                return "#" + newColor;
            } else {
                console.log("basicColor=" + basicColor);
                var newColor = factorColor(basicColor.slice(1), 2);
                console.log("newColor=" + newColor);
                return "#" + newColor;
            }
        };

        $scope.intChapterState = function () {
            if ($scope.chapters) {
                console.log(">>>>Init Chapter State");
                for (var i = 0; i < $scope.chapters.length; i++) {
                    $scope.chapters[i].collapsed = false;
                    $scope.chapters[i].collapsed_bt_img_url = "assets/img/downArrow-large.png";

                    var imageId = $scope.chapters[i].Main_Picture;

                    function getBackgroundImage(index, chapterId) { // displayName() is the inner function, a closure

                        //var imageUrl = "/services/data/v35.0/sobjects/Attachment/"+chapterId+ "EAA/Body";

                        ImageCacheService.isImageCached(chapterId).then(function (result) {

                                if (result) {
                                    ImageCacheService.retrieveImage(chapterId).then(function (result) {
                                        $scope.chapters[index].backgroundImage = result;
                                        //console.log("Chapter " + chapterId + "-retrieveImage Result:");
                                    }, function (error) {
                                        console.log("retrieveImage Error:" + JSON.stringify(error));
                                    });
                                } else {
                                    console.log("getAttachmentBody using " + chapterId);
                                    ForceClientService.getAttachmentBody(chapterId).then(function (result) {
                                            if (result) {

                                                ImageCacheService.cacheImageFile(chapterId, result).then(function (result) {
                                                    ImageCacheService.retrieveImage(chapterId).then(function (result) {
                                                        $scope.chapters[index].backgroundImage = result;
                                                        //console.log("Chapter " + chapterId + "-retrieveImage Result:" + result);
                                                    }, function (error) {
                                                        console.log("retrieveImage Error:" + JSON.stringify(error));
                                                    });

                                                }, function (error) {
                                                    console.log("cacheImageFile Error:" + JSON.stringify(error));
                                                });
                                            }
                                        },
                                        function (error) {
                                            console.log("cacheImageFile Error:" + JSON.stringify(error));
                                        });

                                }

                            },
                            function (error) {
                                console.log("isImageCached Error:" + JSON.stringify(error));
                            });
                    }

                    if (imageId != null && UtilsService.isMobileDevice()) {
                        getBackgroundImage(i, imageId);
                    }

                }
            }

        };
        //Init Application
        //$scope.loadApplication();
        $scope.intChapterState();


        $scope.toggleChapter = function (data) {
            //console.log("Toggle Chapter:" + data.collapsed);
            if (data.collapsed == undefined) {
                data.collapsed = false;
            }

            data.collapsed = !data.collapsed;
            if (data.collapsed) {
                //data.Main_Colour = $scope.getBackgroundColor(data.Main_Colour, true);
                data.collapsed_bt_img_url = "assets/img/upArrow-large.png";
            } else {
                //data.Main_Colour = $scope.getBackgroundColor(data.Main_Colour, false);
                data.collapsed_bt_img_url = "assets/img/downArrow-large.png";
            }
        };

        $scope.gotoChapter = function (data) {
            ApplicationService.setCurrentSubChapter(data);
            $state.go("app.chapter");
        };

        $scope.gotoSearch = function () {
            $state.go("app.search");
        };

        $scope.goToFAQ = function () {

            var faqPaths = $scope.application.FAQ;
            //faqPaths = "a2Wc0000000ekc5EAA-a2Wc0000000eOyxEAE-a2Yc0000000l3ULEAY";
            console.log("FAQ Path:" + faqPaths);
            if (faqPaths != null) {

                var faqIds = faqPaths.split('-');
                var lastId = faqIds[faqIds.length - 1];

                if (ApplicationService.isLeftNodeById(lastId)) {
                    $state.go("app.content", {
                        contentId: lastId,
                        from: "app.home"
                    });

                } else {
                    $state.go("app.faq", {
                        from: "app.home"
                    });
                    /*if (ApplicationService.setCurrentSubChapterById(faqIds[faqIds.length - 1])) {
                        $state.go("app.faq");
                    } else {
                        UtilsService.dialog(
                            $filter('translate')('cl.global.lb_message'),
                            $filter('translate')('cl.home.msg_faqNotFound'),
                            $filter('translate')('cl.global.btn_ok')
                        );
                    }*/
                }

            }

        };

        /*
         * The view has fully entered and is now the active view. This event will fire, whether it was the first load or a cached view.
         */
        $scope.$on('$ionicView.enter', function () {
            console.log("app.home enter");
            // code to run each time view is entered
            //$scope.from = $stateParams.reload;
            try {
                console.log("Reload Flag:" + ApplicationService.getReloadFlag());

                if (ApplicationService.getReloadFlag()) {
                    $scope.application = ApplicationService.getApplication();
                    $scope.chapters = ApplicationService.getContents();

                    $scope.intChapterState();

                    ApplicationService.setReloadFlag(0);
                }
            } catch (e) {
                console.log(e);
            }

        });

    });
