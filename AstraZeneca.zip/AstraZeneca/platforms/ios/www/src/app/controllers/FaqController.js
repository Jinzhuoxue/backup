angular.module('AstraZeneca.App')
    .controller('FaqController', function ($scope, $state, $rootScope, $filter, $stateParams, ApplicationService, UtilsService, HtmlContentDisplayService) {

        /*
         * Init the view state using model
         */
        $scope.initSectionState = function () {
            try {
                if ($scope.subChapter && $scope.subChapter.Nodes) {
                    for (var i = 0; i < $scope.subChapter.Nodes.length; i++) {
                        var section = $scope.subChapter.Nodes[i];

                        console.log(">>>>Init Section State:" + section.Id);
                        if ($scope.needExpand(section.Id)) {

                            section.collapsed = true;
                            section.collapsed_bt_img_url = "assets/img/upArrow-gray-small.png";
                            section.text_color = "#9db0ae";

                        } else {
                            section.collapsed = false;
                            section.collapsed_bt_img_url = "assets/img/downArrow-gray-small.png";
                            section.text_color = "#3f4444";
                        }
                        $scope.initSubNodeState(section.Nodes);

                    }
                }

            } catch (e) {
                console.log(">>>>initSectionState" + e);
            }

        };

        $scope.initSubNodeState = function (nodes) {
            //If the noeds is not a array ,return unfefined
            if (!angular.isArray(nodes)) return;

            angular.forEach(nodes, function (node) {
                console.log(">>>>Init SubSubSection:" + node.Id);
                if (node.Nodes == null || node.Nodes.length == 0) {
                    node.collapsed = false;
                    node.isLeaf = true;
                    node.collapsed_icon_class = "icon ion-ios-arrow-right";
                    node.collapsed_bt_img_url = "assets/img/rightArrow-gray-small.png";
                    node.text_color = "#3f4444";
                } else {
                    node.isLeaf = false;

                    if ($scope.needExpand(node.Id)) {

                        node.collapsed = true;
                        node.collapsed_bt_img_url = "assets/img/upArrow-gray-small.png";
                        node.text_color = "#9db0ae";

                    } else {
                        node.collapsed = false;
                        node.collapsed_bt_img_url = "assets/img/downArrow-gray-small.png";
                        node.text_color = "#3f4444";
                    }
                }
                $scope.initSubNodeState(node.Nodes);

            })

        };

        $scope.needExpand = function (nodeId) {
            try {
                if ($scope.faqIds) {

                    if ($scope.faqIds.indexOf(nodeId) == -1) {
                        console.log("needExpand:" + nodeId);
                        return false;
                    } else {
                        console.log("not needExpand:" + nodeId);
                        return true;
                    }

                } else {
                    console.log("not needExpand:" + nodeId);
                    return false;
                }
            } catch (e) {
                console.log("needExpand:" + e);
            }

        };

        $scope.initSectionState();


        $scope.toggleSectionPane = function (data) {
            data.collapsed = !data.collapsed;
            if (data.collapsed) {
                data.collapsed_icon_class = "button button-clear icon ion-ios-arrow-up";
                data.collapsed_bt_img_url = "assets/img/upArrow-gray-small.png";
                data.text_color = "#9db0ae";
            } else {
                data.collapsed_icon_class = "button button-clear icon ion-ios-arrow-down";
                data.collapsed_bt_img_url = "assets/img/downArrow-gray-small.png";
                data.text_color = "#3f4444";
            }
        };

        $scope.clickSubSectionPane = function (data) {
            if (data.isLeaf) {

                //HtmlContentDisplayService.loadHtmlContent(data.Id, true);
                $state.go("app.content", {
                    contentId: data.Id,
                    from: "app.faq"
                });

                /*var contentURL = cordova.file.documentsDirectory + data.Id;
                        var contentFileName = data.Id + ".html";
                
                        console.log("HtmlFile:" + contentURL+"/"+contentFileName);
                        var ref = cordova.InAppBrowser.open(contentURL+"/"+contentFileName, '_blank', 'location=no');*/

            } else {
                data.collapsed = !data.collapsed;
                if (data.collapsed) {
                    data.collapsed_icon_class = "icon ion-ios-arrow-up";
                    data.collapsed_bt_img_url = "assets/img/upArrow-gray-small.png";
                    data.text_color = "#9db0ae";
                } else {
                    data.collapsed_icon_class = "icon ion-ios-arrow-down";
                    data.collapsed_bt_img_url = "assets/img/downArrow-gray-small.png";
                    data.text_color = "#3f4444";
                }
            }

        };

        $scope.gotoSearch = function () {
            $state.go("app.search");
        };

        $scope.back = function () {
            $state.go($scope.from);
        };

        /*
         * The view has fully entered and is now the active view. This event will fire, whether it was the first load or a cached view.
         */
        $scope.$on('$ionicView.enter', function () {
            $scope.from = $stateParams.from;
            var faqPaths = ApplicationService.getApplication().FAQ;
            //faqPaths = "a2Wc0000000ekc5EAA-a2Wc0000000eOyxEAE-a2Yc0000000l3ULEAY";
            console.log("FAQ Path:" + faqPaths);
            if (faqPaths != null) {

                $scope.faqIds = faqPaths.split('-');

                if ($scope.faqIds.length > 2) {
                    var lastId = $scope.faqIds[$scope.faqIds.length - 1];

                    var chapterId = $scope.faqIds[1];

                    //parent node of the target view model
                    $scope.parentChapter = ApplicationService.findChapterById(chapterId);

                    //the target view model
                    for (var i = 0; i < $scope.parentChapter.Nodes.length; i++) {
                        var subchapter = $scope.parentChapter.Nodes[i];
                        if (subchapter.Id == $scope.faqIds[2]) {
                            $scope.subChapter = subchapter;
                            break;
                        }
                    }

                    if ($scope.subChapter == null) {
                        UtilsService.dialog(
                            $filter('translate')('cl.global.lb_message'),
                            $filter('translate')('cl.home.msg_faqNotFound'),
                            $filter('translate')('cl.global.btn_ok')
                        );
                    } else {
                        $scope.initSectionState();
                    }
                } else {
                    UtilsService.dialog(
                        $filter('translate')('cl.global.lb_message'),
                        $filter('translate')('cl.home.msg_faqNotFound'),
                        $filter('translate')('cl.global.btn_ok')
                    );
                }

            } else {
                UtilsService.dialog(
                    $filter('translate')('cl.global.lb_message'),
                    $filter('translate')('cl.home.msg_faqNotFound'),
                    $filter('translate')('cl.global.btn_ok')
                );
            }


            console.log("$ionicView.enter");
        });
    });
