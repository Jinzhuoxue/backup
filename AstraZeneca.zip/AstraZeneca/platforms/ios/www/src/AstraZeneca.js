// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('AstraZeneca', ['ionic', 'AstraZeneca.App', 'AstraZeneca.Common'])

.run(function ($ionicPlatform, $rootScope, $state, $ionicLoading, LoginService, UtilsService, ForceClientService,
    SmartStoreService, SmartStoreSyncService, ApplicationService, ZipFileService, SMARTSTORE_SOUP_STATUS, $window) {

    //the default language od device
    $rootScope.language = "en-US";
    $rootScope.currentMainPage = "app.home";

    $ionicPlatform.ready(function () {
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        if (window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            cordova.plugins.Keyboard.disableScroll(true);

        }
        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
        }

    });

    // debugging for routing
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        console.log('$stateChangeStart to ' + toState.to + '- fired when the transition begins. toState,toParams : \n', toState, toParams);
    });
    $rootScope.$on('$stateNotFound', function (event, unfoundState, fromState, fromParams) {
        console.log('$stateNotFound ' + unfoundState.to + '  - fired when a state cannot be found by its name.');
        console.log(unfoundState, fromState, fromParams);
    });
    $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
        console.log('$stateChangeSuccess to ' + toState.name + '- fired once the state transition is complete.');
    });
    $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
        console.log('$stateChangeError - fired when an error occurs during transition.' + JSON.stringify(error));
        console.log(arguments);
    });
    $rootScope.$on('$viewContentLoaded', function (event) {
        console.log('$viewContentLoaded - fired after dom rendered', event);
    });

    if (UtilsService.isMobileDevice()) {

        /* Wait until cordova is ready to initiate the use of cordova plugins and app launch */
        document.addEventListener("deviceready", function () {

            /**
             * @description check if User is off- or online
             */
            $rootScope.online = navigator.onLine;

            //the default language od device
            $rootScope.language = "en_US";

            // USER IS OFFLINE
            $window.addEventListener("offline", function () {
                $rootScope.$apply(function () {
                    $rootScope.online = false;
                });
            }, false);

            // USER IS ONLINE
            $window.addEventListener("online", function () {
                $rootScope.$apply(function () {
                    $rootScope.online = true;
                });
            }, false);


            /*window.resolveLocalFileSystemURL(cordova.file.documentsDirectory, function (fs) {

                function toArray(list) {
                    return Array.prototype.slice.call(list || [], 0);
                }

                //Reading the directory's contents
                var dirReader = fs.createReader();
                var entries = [];

                // Call the reader.readEntries() until no more results are returned.
                var readEntries = function () {
                    dirReader.readEntries(function (results) {
                        if (!results.length) {
                            entries.forEach(function (entry, i) {
                                //console.log("Find Entry:" + entry.name);
                            });
                        } else {
                            entries = entries.concat(toArray(results));
                            readEntries();
                        }
                    }, function (error) {
                        console.log("File error:" + error);
                    });
                };

                readEntries(); // Start reading dirs.
            }, function (error) {
                console.log("File error:" + error);
            });*/


            //Get Globalization information
            /*navigator.globalization.getPreferredLanguage(
                function (language) {
                    console.log('language: ' + language.value + '\n');
                    $rootScope.$apply(function () {
                        $rootScope.language = language.value;
                    });*/

                    LoginService.oauthViaDevicePlugin(function () {
                        $ionicLoading.show();

                        console.log("oauthViaDevicePlugin succeeded");

                        if ($rootScope.online) {
                            ForceClientService.getUserLanguage().then(function (language) {
                                console.log("user language:" + language);
                                //$rootScope.language = language;
                                
                                var isLoaded = false;
                                // Register soups
                                SmartStoreService.registerSoups().then(function (result) {
                                    console.log("logged in and setupSoups result: " + JSON.stringify(result));

                                    //if ($rootScope.online) {

                                    $ionicLoading.hide();
                                    $state.go("app.splash",{language:language});
                                    /*SmartStoreSyncService.startSync(language).then(function (success) {
                                        console.log("startSync Success: " + success.total);

                                        //ApplicationService.setApplication(success.application);
                                        ApplicationService.updateApplicationUsingSyncResults(success.results);

                                        $ionicLoading.hide();
                                        //$state.go("app.home");
                                    }, function (error) {
                                        console.log("startSync Error: " + JSON.stringify(error));
                                        $ionicLoading.hide();
                                        //$state.go("app.home");
                                        $state.go("app.home");
                                    }, function (notify) {
                                        //console.log("startSync Notify: " + JSON.stringify(notify));
                                        if (notify.application != null && !isLoaded) {
                                            ApplicationService.setApplication(notify.application);

                                            $ionicLoading.hide();
                                            $state.go("app.splash");
                                            isLoaded = true;
                                        } 
                                    });*/
                                    /*} else {
                                        console.log("Offline Init>>>>>>>>>>>>");
                                        ApplicationService.loadApplication(language).then(function (success) {
                                            console.log("Offline Mode: " + JSON.stringify(success));

                                            $ionicLoading.hide();
                                            $state.go("app.home");
                                        }, function (error) {
                                            console.log("Offline Mode Error: " + JSON.stringify(error));
                                            $ionicLoading.hide();
                                            $state.go("app.home");
                                        }, function (notify) {
                                            console.log("Offline Mode Notify: " + JSON.stringify(notify));
                                        });
                                    }*/
                                });
                            }, function (error) {
                                UtilsService.dialog(
                                    $filter('translate')('cl.global.lb_message'),
                                    $filter('translate')('cl.home.msg_failedToGetUserInfo'),
                                    $filter('translate')('cl.global.btn_ok')
                                );
                            });
                        } else {
                            console.log("Offline Init>>>>>>>>>>>>");
                            ApplicationService.loadApplication().then(function (success) {
                                console.log("Offline Mode: " + JSON.stringify(success));

                                $ionicLoading.hide();
                                $state.go("app.home");
                            }, function (error) {
                                console.log("Offline Mode Error: " + JSON.stringify(error));
                                $ionicLoading.hide();
                                $state.go("app.home");
                            }, function (notify) {
                                console.log("Offline Mode Notify: " + JSON.stringify(notify));
                            });
                        }

                    });
                /*},
                function (error) {
                    $rootScope.$apply(function () {
                        $rootScope.language = "en-US";
                    });

                    LoginService.oauthViaDevicePlugin(function () {

                        console.log("oauthViaDevicePlugin succeeded");

                        // Initialize  soups
                        SmartStoreService.setupSoups().then(function (result) {
                            console.log("logged in and setupSoups result: " + JSON.stringify(result));

                            //ApplicationService.loadApplication($rootScope.language);
                            $state.go("app.home", {
                                reloadFlag: 1
                            });
                        });
                    });
                }
            );*/

        }, false);
    } else {
        $(document).ready(function () {
            //LoginService.oauthViaBrowserPopup(LoginService.showUsersList);
            console.log("loadApplication");
            ApplicationService.loadApplication($rootScope.language).then(
                function (result) {
                    //Get the count of left node
                    var leftNodeCount = ApplicationService.countLeftNodes(result);
                    console.log(">>>> Left Node Count: " + leftNodeCount);
                    console.log("Redirect to home");
                    $state.go("app.splash");
                }
            );
        });
    }
})

.config(function ($translateProvider) {
    $translateProvider.useStaticFilesLoader({
        prefix: 'src/common/i18n/locale-',
        suffix: '.json'
    });
    $translateProvider.preferredLanguage('en');
    $translateProvider.fallbackLanguage('en');
})

.config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('app', {
            url: '/app',
            abstract: true,
            templateUrl: 'src/app/templates/menu.html',
            controller: 'MenuController'
        })

    .state('app.splash', {
        url: '/splash/:language',
        views: {
            'menuContent': {
                templateUrl: 'src/app/templates/splash.html',
                controller: 'SplashScreenController'
            }
        }
    })

    .state('app.home', {
        url: '/home/:reload',
        views: {
            'menuContent': {
                templateUrl: 'src/app/templates/home.html',
                controller: 'HomeController'

            }
        }
    })

    .state('app.chapter', {
            url: '/chapter',
            views: {
                'menuContent': {
                    templateUrl: 'src/app/templates/chapter.html',
                    controller: 'ChapterController'
                }
            }
        })
        .state('app.faq', {
            url: '/faq/:from',
            views: {
                'menuContent': {
                    templateUrl: 'src/app/templates/faq.html',
                    controller: 'FaqController'
                }
            }
        })

    .state('app.content', {
        url: '/content/:contentId/:from',
        views: {
            'menuContent': {
                templateUrl: 'src/app/templates/content.html',
                controller: 'ContentController'
            }
        }
    })

    .state('app.search', {
        url: '/search',
        views: {
            'menuContent': {
                templateUrl: 'src/app/templates/search.html',
                controller: 'SearchController'
            }
        }
    })

    .state('app.sync', {
        url: '/sync',
        views: {
            'menuContent': {
                templateUrl: 'src/app/templates/sync.html',
                controller: 'SyncController'
            }
        }
    });
    // if none of the above states are matched, use this as the fallback
    //$urlRouterProvider.otherwise('/app/home');
});
