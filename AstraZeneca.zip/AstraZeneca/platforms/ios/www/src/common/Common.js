var astraCommonModule = angular.module('AstraZeneca.Common', ['pascalprecht.translate', 'angular-md5']);


astraCommonModule.directive("debug", function ($compile) {
    return {
        terminal: true,
        priority: 10000000,
        link: function (scope, element) {
            var clone = element.clone();
            element.attr("sytle", "color:red");
            clone.removeAttr("debug");
            var clonedElement = $compile(clone)(scope);
            element.after(clonedElement);
        }
    }
});

