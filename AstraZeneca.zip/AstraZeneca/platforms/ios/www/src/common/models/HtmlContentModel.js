angular.module('AstraZeneca.Common')
    .service('HtmlContentModel', function ($q, $http, UtilsService) {
        var service = this;

        var objectName = "HtmlContent";

        var fields = [
            'Id',
            'updated',
            'content',
            'lastSyncDown',
        ];

        service.generateObject = function (_id, _content, _lastSyncDown) {
            return {
                Id: _id,
                updated: 1,
                content: _content,
                lastSyncDown: _lastSyncDown
            };
        };

        service.upsert = function (htmlContent) {

            var deferred = $q.defer();

            navigator.smartstore.upsertSoupEntries(objectName, [htmlContent], function (upsertedObj) {
                deferred.resolve(upsertedObj);
            }, function (error) {
                alert(error);
            });

            return deferred.promise;
        };

        service.updateByExtternalId = function (htmlContent) {
            var deferred = $q.defer();

            navigator.smartstore.upsertSoupEntriesWithExternalId(false,objectName, [htmlContent], "Id", function (upsertedObj) {
                deferred.resolve(upsertedObj);
            }, function (error) {
                alert(error);
            });

            return deferred.promise;
        };

        service.fetchByContentId = function (contentId) {

            if (UtilsService.isMobileDevice()) {
                var deferred = $q.defer();
                var result = null;

                var querySpec = navigator.smartstore.buildExactQuerySpec("Id", contentId, 1);

                navigator.smartstore.querySoup(objectName, querySpec, function (cursor) {

                    var currentPageEntries = cursor.currentPageOrderedEntries;

                    angular.forEach(currentPageEntries, function (entry) {
                        result = entry;
                    });

                    deferred.resolve(result);
                }, alert);

                return deferred.promise;
            }
        };

        service.fetchCount = function () {
            var deferred = $q.defer();

            var querySpec = navigator.smartstore.buildSmartQuerySpec("select count(*) from {" + objectName + "}", 1);
            navigator.smartstore.runSmartQuery(querySpec, function (cursor) {

                var currentPageEntries = cursor.currentPageOrderedEntries;
                var count = 0;

                _.each(currentPageEntries, function (entry) {
                    count = entry;
                });

                deferred.resolve(count);
            });

            return deferred.promise;
        };


        service.fetchLastSyncDown = function () {
            var deferred = $q.defer();
            var lastSyncDown;

            var querySpec = navigator.smartstore.buildSmartQuerySpec("select max({" + objectName + ":lastSyncDown}) from {" + objectName + "}", 1);
            navigator.smartstore.runSmartQuery(querySpec, function (cursor) {

                var currentPageEntries = cursor.currentPageOrderedEntries;

                _.each(currentPageEntries, function (entry) {
                    lastSyncDown = entry;
                });

                deferred.resolve(lastSyncDown);
            });

            return deferred.promise;
        };

        service.searchByContent = function (matchKey) {

            if (UtilsService.isMobileDevice()) {
                var deferred = $q.defer();
                var results = [];

                var querySpec = navigator.smartstore.buildMatchQuerySpec("content", matchKey);

                navigator.smartstore.querySoup(objectName, querySpec, function (cursor) {

                    var currentPageEntries = cursor.currentPageOrderedEntries;

                    angular.forEach(currentPageEntries, function (entry) {
                        results.push(entry);
                    });

                    deferred.resolve(results);
                }, alert);

                return deferred.promise;
            }
        };

    });;
