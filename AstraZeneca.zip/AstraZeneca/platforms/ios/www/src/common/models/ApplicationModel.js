angular.module('AstraZeneca.Common')
    .service('ApplicationModel', function ($q, $http, UtilsService) {
        var service = this,
            MODEL = '/application/';

        var objectName = "Application";

        var fields = [
            'Id',
            'Language',
            'JSONBody',
            'Timestamp'
        ];

        var filterCriteria = null;

        var lookupModStamp = '';

        service.generateObject = function (id, language, jsonBody) {
            return {
                Id: id,
                Language: language,
                JSONBody: jsonBody
                    //Timestamp: Date.now()
            };
        };

        service.getName = function () {
            return objectName;
        };

        service.getFields = function () {
            return fields;
        };

        /**
         * returns the soql query filter criteria for the current object
         * @returns {string}
         */
        service.getFilterCriteria = function () {
            return filterCriteria;
        };

        /**
         * returns the lookupModStamp condition for synchronization
         * @returns {string}
         */
        service.getLookupModStamp = function () {
            return lookupModStamp;
        };

        /*
         * Fetch the application tree structure by specified language and region code. 
         * If the specifed application is not found, using "en-US" as default language to find one.
         * @param the language and region code, the format is "laguage-region", for example, "en-US".
         * @return the application tree structure
         */
        service.fetchByLanguage = function (language) {

            console.log("Language:" + language);

            if (UtilsService.isMobileDevice()) {
                var deferred = $q.defer();
                var application = null;

                var querySpec = navigator.smartstore.buildExactQuerySpec("Language", language, 1);

                navigator.smartstore.querySoup(objectName, querySpec, function (cursor) {

                    var currentPageEntries = cursor.currentPageOrderedEntries;

                    angular.forEach(currentPageEntries, function (entry) {
                        application = entry;
                    });

                    //console.log("query application result: " + JSON.stringify(application));

                    //No specified languge application found,using the 'en-Us' as default.
                    if (application == null) {
                        var querySpec = navigator.smartstore.buildAllQuerySpec("_soupLastModifiedDate", "descending", 1);
                        navigator.smartstore.querySoup(objectName, querySpec, function (cursor) {

                            var currentPageEntries = cursor.currentPageOrderedEntries;

                            angular.forEach(currentPageEntries, function (entry) {
                                application = entry;
                            });

                            //console.log("query default application result: " + JSON.stringify(application));

                            if (application == null) {
                                deferred.resolve(null);
                            } else {
                                deferred.resolve(JSON.parse(application.JSONBody));
                            }
                        }, function (error) {
                            //alert("Error in ApplicationModel - fetch(): " + error);
                            deferred.error(error);
                        });

                    } else {
                        deferred.resolve(JSON.parse(application.JSONBody));
                    }

                }, function (error) {
                    alert("Error in ApplicationModel - fetch(): " + error);

                });

                return deferred.promise;
            } else {

                return $http.get("src/common/json/Application.js").then(function (response) {
                    console.log("Application response:", response);
                    return response.data;
                });
            }
        };

        /*
         * Fetch the latest application tree structure based on the _soupLastModifiedDate feild. 
         * @return the application tree structure, if not found, return null
         */
        service.fetchLatestApplication = function () {

            if (UtilsService.isMobileDevice()) {
                var deferred = $q.defer();
                var application = null;
                var querySpec = navigator.smartstore.buildAllQuerySpec("_soupLastModifiedDate", "descending", 1);
                navigator.smartstore.querySoup(objectName, querySpec, function (cursor) {

                    var currentPageEntries = cursor.currentPageOrderedEntries;

                    angular.forEach(currentPageEntries, function (entry) {
                        application = entry;
                    });

                    //console.log("query default application result: " + JSON.stringify(application));

                    if (application == null) {
                        deferred.resolve(null);
                    } else {
                        deferred.resolve(JSON.parse(application.JSONBody));
                    }
                }, function (error) {
                    //alert("Error in ApplicationModel - fetch(): " + error);
                    deferred.error(error);
                });

                return deferred.promise;
            } else {

                return $http.get("src/common/json/Application.js").then(function (response) {
                    console.log("Application response:", response);
                    return response.data;
                });
            }
        };


        service.all = function () {
            return $http.get("src/common/json/Application.js").then(function (response) {
                console.log("Application response:", response);
                return response.data;
            });
        };

    });;
