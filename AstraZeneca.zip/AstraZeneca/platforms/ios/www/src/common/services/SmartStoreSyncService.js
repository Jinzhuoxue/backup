angular.module('AstraZeneca.Common')
    .service('SmartStoreSyncService', function ($q, $http, $timeout, $filter, ForceClientService, ApplicationService, HtmlContentService, ApplicationModel, HtmlContentModel, ZipFileService, UtilsService) {
        var service = this;

        var application = null;

        /**
         * Determine if current user has already synced at least once.
         */
        service.isSynced = function () {
            return HtmlContentModel.fetchSobjectCount().then(function (count) {
                if (count && count > 0) {
                    return true;
                } else {
                    return false;
                }
            });
        };

        /**
         * Start sync.
         */
        service.startSync = function (language) {

            var deferred = $q.defer();

            console.log("Sync Application with Language:" + language);

            var oldApplication = null;
            //Define Sync Result
            var syncResult = {
                application: null,
                results: [],
                processed: 0,
                failed: 0,
                total: 0
            };

            //Step 1: Get the latest application from salesforce based on the language.
            service.syncApplication(language).then(function (result) {

                console.log(">>>> Application Synced: " + JSON.stringify(result));
                syncResult.application = result;
                deferred.notify(syncResult);

                //Get the count of left node
                //var leftNodeCount = ApplicationService.countLeftNodes(result);

                var idList = ApplicationService.getLeftNodeIDAsList(result);
                console.log(">>>> Left Nodes: " + idList.toString());
                syncResult.total = idList.length;

                //Step 2: Sync the latest html content for each left node of the application.

                service.startSyncHtmlContents(result, idList).then(function (result) {

                    syncResult.results = result.results;
                    syncResult.processed = result.processed;
                    syncResult.failed = result.failed;

                    console.log("Sync Result: " + JSON.stringify(result));
                    deferred.resolve(syncResult);

                }, function (error) {
                    alert("SyncHtmlContents Error: " + JSON.stringify(error));
                    deferred.reject(error);
                }, function (process) {
                    syncResult.results = process.results;
                    syncResult.processed = process.processed;
                    syncResult.failed = process.failed;

                    deferred.notify(syncResult);

                });

            }, function (error) {
                //alert("error: " + JSON.stringify(error));
                deferred.reject(error);
            }, function (notify) {
                deferred.notify(notify);
            });

            return deferred.promise;
        };


        /**
         * Sync the application using specified language
         */
        service.syncApplication = function (language) {

            var deferred = $q.defer();
            var forceClient = ForceClientService.getForceClient();

            forceClient.apexrest("/ArticleTreeFecther/V01/" + language, "GET", null, null, function (result) {
                // SFDC rest call successfully
                if (result) {

                    var records = [];

                    //Generate a application object using the fetched information
                    var record = ApplicationModel.generateObject(result.Id, result.Language, JSON.stringify(result));
                    records.push(record);

                    //Upsert the application object into soup
                    navigator.smartstore.upsertSoupEntriesWithExternalId(false, "Application", records, "Id", function (success) {

                        console.log(">>>> Upsert Application into soup result: " + JSON.stringify(success));

                        deferred.resolve(result);

                    }, function (error) {
                        UtilsService.dialog(
                            $filter('translate')('cl.global.lb_message'),
                            $filter('translate')('cl.home.msg_upsertIntoSoupError'),
                            $filter('translate')('cl.global.btn_ok')
                        );
                        deferred.reject(error);
                    });

                }

            }, function (error) {
                //No Application Found
                UtilsService.dialog(
                    $filter('translate')('cl.global.lb_message'),
                    $filter('translate')('cl.home.msg_appNotFound'),
                    $filter('translate')('cl.global.btn_ok')
                );
                deferred.reject(error);
            });

            return deferred.promise;
        };

        service.startSyncHtmlContents = function (application, nodeList) {

            console.log(">>>> start Sync HtmlContents: " + JSON.stringify(nodeList));
            var deferred = $q.defer();

            var syncStatus = {
                results: [],
                processed: 0,
                failed: 0
            };

            //If the param is not a array,reject it
            if (!angular.isArray(nodeList)) {
                deferred.reject("No sync node list provide");
            }


            var resolvedPromise = 0;

            function checkSyncStatus() {
                if (resolvedPromise == nodeList.length) {
                    console.log(">>>>Sync HtmlContents Finshed:" + JSON.stringify(syncStatus));
                    deferred.resolve(syncStatus);
                } else {
                    deferred.notify(syncStatus);
                    service.startSyncHtmlContent(application, nodeList[resolvedPromise]).then(successHandler, errorHandler);
                }
            }

            function errorHandler(error) {
                //console.log(">>>> startSyncHtmlContents error: " + JSON.stringify(error));

                //var result = error.message + JSON.stringify(error.error);
                //console.log(result);
                syncStatus.results.push(error);
                syncStatus.failed++;
                resolvedPromise++;

                checkSyncStatus();
            }

            function successHandler(result) {
                //var result = "[" + result + "]Sync successfully";
                //console.log(result);
                syncStatus.results.push(result);

                if (syncStatus.status == 1) {
                    syncStatus.processed++;
                }

                resolvedPromise++;
                checkSyncStatus();
            }


            if (nodeList.length == 0) {
                deferred.resolve(syncStatus);
            } else {
                service.startSyncHtmlContent(application, nodeList[resolvedPromise]).then(successHandler, errorHandler);
            }


            /*_.each(nodeList, function (node, index) {

                service.startSyncHtmlContent(application, node).then(successHandler, errorHandler);

            });*/

            return deferred.promise;
        }

        /*
         * Sync the HTML content for each left node of application
         * @param idList A array including all the id of left node
         */
        service.startSyncHtmlContent = function (application, nodeId) {


                var deferred = $q.defer();
                var forceClient = ForceClientService.getForceClient();

                var syncInfo = {
                    Id: "",
                    path: "",
                    status: 0, //-1:failed to sync; 0:No need to sync; 1:synced
                    message: "",
                    error: null
                };

                syncInfo.Id = nodeId;
                if (application != null) {
                    syncInfo.path = ApplicationService.readNodePath(application, nodeId);
                }

                function errorHandler(message, error) {
                    console.log("startSyncHtmlContent error:" + JSON.stringify(error));
                    syncInfo.status = -1;
                    syncInfo.message = message;
                    syncInfo.error = error;

                    deferred.reject(syncInfo);
                }

                //Retrieve local record from soup
                HtmlContentModel.fetchByContentId(nodeId).then(function (localContent) {

                        //console.log(">>>>HtmlContent result in soup: " + JSON.stringify(localContent));

                        var nodeAttachmentPath = "/AttachmentFecther/V01/" + nodeId;

                        //Get HTML Content information using REST interface
                        forceClient.apexrest(nodeAttachmentPath, "GET", null, null, function (result) {

                                /*{"attributes":{"type":"Attachment","url":"/services/data/v29.0/sobjects/Attachment/00Pc0000002biWyEAI"},
                                "Body":"/services/data/v29.0/sobjects/Attachment/00Pc0000002biWyEAI/Body",
                                "ParentId":"a2Yc0000000l3UQEAY",
                                "LastModifiedDate":"2015-12-23T05:54:04.000+0000",
                                "Id":"00Pc0000002biWyEAI"}
                                 */

                                //console.log(">>>> /AttachmentFecther result: " + JSON.stringify(result));

                                // Get Html content successfully 
                                if (result.Body != null) {
                                    var dotIndex = result.LastModifiedDate.indexOf('.');
                                    var lastModifiedTimestamp = result.LastModifiedDate.slice(0, dotIndex);

                                    if (localContent == null || Date.parse(lastModifiedTimestamp) > localContent.lastSyncDown) {

                                        var destUrl = cordova.file.documentsDirectory + nodeId;
                                        //Step0:Clear the old related files
                                        HtmlContentService.removeDirectory(destUrl).then(function (flag) {

                                            //Step1:Download the attachment zip file
                                            ZipFileService.downloadZipFile(nodeId, result.Body).then(
                                                function (result) {
                                                    console.log(">>>> Zip File : " + result);
                                                    //var destUrl = cordova.file.documentsDirectory + nodeId;
                                                    //Step2: unzip the zip file into specified folder
                                                    ZipFileService.unzipFile(result, destUrl).then(
                                                        function (success) {
                                                            console.log("Unzip file success:" + JSON.stringify(success));
                                                            var folderPath = nodeId;
                                                            var fileName = nodeId + ".html";

                                                            //Step4: Read the unziped html file and write the content(convert html to plain text) into soup
                                                            HtmlContentService.findHtmlFileInFolder(destUrl).then(function (result) {
                                                                //Step5: Write the latest content in to new html file
                                                                console.log("Find Result:" + result);
                                                                var srcFileName = result.slice(result.lastIndexOf('/') + 1);
                                                                console.log("File Name:" + srcFileName);

                                                                HtmlContentService.readHtmlContent(srcFileName, destUrl).then(function (content) {
                                                                    //Remove html labels
                                                                    var contentNoHtmlLabel = HtmlContentService.removeHtmlLabel(content);
                                                                    //Add name path to content
                                                                    contentNoHtmlLabel = "[" + syncInfo.path + "]" + contentNoHtmlLabel;

                                                                    HtmlContentService.writeHtmlContent(fileName, destUrl, content).then(function (success) {

                                                                        //console.log(">>>>HtmlContent write into file: " + fileName + ":" + success);
                                                                        var records = [];
                                                                        var record = HtmlContentModel.generateObject(nodeId, contentNoHtmlLabel, Date.parse(lastModifiedTimestamp));
                                                                        records.push(record);

                                                                        //Upsert the application into soup
                                                                        //console.log("Upsert the application into soup:", JSON.stringify(records));
                                                                        navigator.smartstore.upsertSoupEntriesWithExternalId(false, "HtmlContent", records, "Id", function (success) {

                                                                            syncInfo.status = 1;
                                                                            deferred.resolve(syncInfo);

                                                                        }, function (error) {
                                                                            errorHandler("Failed to update html content into soup", error);
                                                                        });

                                                                    }, function (error) {
                                                                        errorHandler("Failed to write new html file:" + HtmlContentService.errorHandler(error), error);
                                                                    });
                                                                }, function (error) {
                                                                    errorHandler("Failed to read html file:" + HtmlContentService.errorHandler(error), error);
                                                                });
                                                            }, function (error) {
                                                                errorHandler("Failed to remove old html file:" + HtmlContentService.errorHandler(error), error);
                                                            });
                                                        },
                                                        function (error) {
                                                            errorHandler("Failed to unzip html zip file", error);
                                                        });
                                                },
                                                function (error) {
                                                    errorHandler("Failed to download html zip file", error);
                                                });
                                        }, function (error) {
                                            errorHandler("Failed to remove directory" + HtmlContentService.errorHandler(error), error);
                                        });
                                    } else {
                                        syncInfo.status = 0;
                                        deferred.resolve(syncInfo);
                                    }

                                } else {
                                    //console.log("No attachment return from REST request");
                                    //errorHandler("No attachment return from REST request", result);
                                    errorHandler("Attachment not found", result);
                                    //syncInfo.status = 0;
                                    //deferred.resolve(syncInfo);
                                }
                            },
                            function (error) {
                                errorHandler("REST request exception", error);
                            });

                    },
                    function (error) {
                        errorHandler("Failed to fetch local html content from soup", error);
                    });

                return deferred.promise;

            }
            /**
             * Start sync down all configured objects determined by method getSyncDownObjects().
             */
        service.startSyncDownObjects = function () {

            // Get all objects need to be synced down
            var objects = service.getSyncDownObjects();

            var deferred = $q.defer();
            var resolvedPromises = 0;

            // Process each object
            _.each(objects, function (obj, index) {

                var promise = service.syncDownObjectRecords(obj.name, objectModelMapping(obj.name).getFields(), objectModelMapping(obj.name).getFilterCriteria(), objectModelMapping(obj.name).getLookupModStamp()).then(function (done) {

                    // Process last page result
                    obj.status.processed += 100;
                    obj.status.total = 100;
                    obj.status.done = true;
                    resolvedPromises++;

                    console.log(">>>> a promise is solved: " + JSON.stringify(obj));
                    console.log(">>>> current promises status: " + JSON.stringify(objects));

                    // If all promises are resolved, then resolve the complete sync down process
                    if (resolvedPromises == objects.length) {
                        deferred.resolve(objects);
                    } else {
                        deferred.notify(objects);
                    }
                }, function (error) {
                    alert("error: " + JSON.stringify(error));
                }, function (notify) {
                    deferred.notify(notify);
                });
            });

            return deferred.promise;
        };

        /**
         * Get all sobjects which need to be synced down from SFDC.
         */
        service.getSyncDownObjects = function () {

            // Whenever a new sobject is added, please import its model dependency and adapt objectModelMapping method as well.
            return [
                {
                    name: "EI_SOP_HTML_Content__c",
                    label: "HTML Content",
                    status: {
                        processed: 0,
                        total: 0
                    }
                }
            ];
        };


        /**
         * Sync down records of a specific sobject from Salesforce
         *
         * @param objectType
         * @param fields
         * @param filterCriteria
         * @param lookupModStamp
         * @returns {*}
         */
        service.syncDownObjectRecords = function (objectType, fields, filterCriteria, lookupModStamp) {

            var deferred = $q.defer();

            // Get last sync down date from local database
            SObjectsModel.fetchByObjectType(objectType).then(function (sobject) {

                var param = {
                    objectType: objectType,
                    fields: fields,
                    filterCriteria: filterCriteria,
                    lookupModStamp: lookupModStamp
                };

                // Set last sync down date from local database as parameters
                if (sobject && sobject.lastSyncDown) {
                    param.lastSyncDown = sobject.lastSyncDown;
                }
                console.log(">>>> sobject: " + JSON.stringify(sobject));

                // Sync all records after last sync down date
                synchronizeFromSFDC(param).then(function (done) {

                    // Update last sync down date to local database
                    SObjectsModel.updateLastSyncDown(objectType, new Date()).then(function () {
                        deferred.resolve(done);
                    });
                }, function (error) {
                    alert(error);
                }, function (progress) {
                    deferred.notify(progress);
                });
            });

            return deferred.promise;
        };

        /**
         * synchronize records from Salesforce
         *
         * @param param
         * @returns {*|b.promise|Function}
         */
        var synchronizeFromSFDC = function (param) {

            var objectType = param.objectType;
            var fields = param.fields;
            var filterCriteria = param.filterCriteria;
            var lookupModStamp = param.lookupModStamp;
            var nextRecordsUrl = param.nextRecordsUrl;
            var done = param.done;
            var totalSize = param.totalSize;
            var records = param.records;
            var deferred = param.deferred || $q.defer();
            var lastSyncDown = param.lastSyncDown;
            var forceClient = ForceClientService.getForceClient();

            if (!nextRecordsUrl) {

                var queryStr = "SELECT " + fields.toString() + " FROM " + objectType;

                var whereClause = null;

                if (lastSyncDown) {
                    if (lookupModStamp == null) {
                        whereClause = "SystemModStamp > " + lastSyncDown;
                    } else {
                        whereClause = lookupModStamp.replace(/\[LAST_SYNC_DATE\]/g, lastSyncDown);
                    }
                }

                if (filterCriteria != null && filterCriteria.length > 0) {
                    if (whereClause == null)
                        whereClause = filterCriteria;
                    else
                        whereClause += " AND " + filterCriteria;
                }

                if (whereClause != null)
                    queryStr += " WHERE " + whereClause;

                console.log(">>>> synchronizeFromSFDC: " + queryStr);

                forceClient.query(queryStr, function (data) {

                    navigator.smartstore.upsertSoupEntriesWithExternalId(false, objectType, data.records, "Id", function (success) {

                        if (data.done == false) {
                            console.log("done = " + data.done + " - query nextRecordsUrl: " + data.nextRecordsUrl);
                            var nextParam = {
                                objectType: objectType,
                                fields: fields,
                                nextRecordsUrl: data.nextRecordsUrl,
                                done: data.done,
                                totalSize: data.totalSize,
                                records: data.records.length,
                                deferred: deferred
                            };
                            synchronizeFromSFDC(nextParam);
                        } else {
                            console.log("done");
                            deferred.resolve({
                                total: data.totalSize,
                                records: data.records.length,
                                nextRecordsUrl: data.nextRecordsUrl
                            });
                        }
                    }, function (error) {
                        alert(error);
                    });

                }, function (error) {
                    alert("error in query: " + JSON.stringify(error));
                });
            } else if (nextRecordsUrl && !done) {

                deferred.notify({
                    total: totalSize,
                    records: records,
                    nextRecordsUrl: nextRecordsUrl
                });
                forceClient.queryMore(nextRecordsUrl, function (data) {

                    navigator.smartstore.upsertSoupEntriesWithExternalId(false, objectType, data.records, "Id", function (success) {

                        if (data.done == false) {
                            console.log("done = " + data.done + " - query nextRecordsUrl: " + data.nextRecordsUrl + " total: " + data.totalSize);
                            var nextParam = {
                                objectType: objectType,
                                fields: fields,
                                nextRecordsUrl: data.nextRecordsUrl,
                                done: data.done,
                                totalSize: data.totalSize,
                                records: data.records.length,
                                deferred: deferred
                            };
                            synchronizeFromSFDC(nextParam);
                        } else {
                            console.log("done");
                            deferred.resolve({
                                total: totalSize,
                                records: data.records.length,
                                nextRecordsUrl: nextRecordsUrl
                            });
                        }
                    });
                }, function (error) {
                    alert("error in nextRecordsUrl: " + error);
                });
            }

            return deferred.promise;
        };



        var queryRelatedRecords = function (queueMessages) {

            console.log(">>>> queryRelatedRecords: " + JSON.stringify(queueMessages));

            // Assume queueMessages are relating to the same object
            var deferred = $q.defer();
            var records = [];
            var recordsQueueMessages = [];

            var querySpec = navigator.smartstore.buildAllQuerySpec("Id", null, BaseModel.pageSizeForAll);
            navigator.smartstore.querySoup(queueMessages[0].objectName, querySpec, function (cursor) {

                var currentPageEntries = cursor.currentPageOrderedEntries;

                angular.forEach(currentPageEntries, function (entry) {
                    var queueMessage = _.findWhere(queueMessages, {
                        recordSoupEntryId: entry._soupEntryId
                    });
                    if (queueMessage) {
                        records.push(entry);
                        recordsQueueMessages.push(queueMessage);
                    }
                });

                deferred.resolve({
                    records: records,
                    queueMessages: recordsQueueMessages
                });
            }, function (error) {
                alert("Error in SmartStoreSyncService - syncUpObjectRecords(): " + error);
            });

            return deferred.promise;

        };

        var omitKeys = function (objs, keys) {
            var newObjs = [];
            _.each(objs, function (obj) {
                var newObj = {};
                for (var key in obj) {
                    if (keys.indexOf(key) == -1) {
                        newObj[key] = obj[key];
                    }
                }
                newObjs.push(newObj);
            });
            return newObjs;
        }


        var objectModelMapping = function (obj) {

            switch (obj) {
                case "Location__c":
                    return LocationsModel;
                    break;
                case "Asset__c":
                    return AssetsModel;
                    break;
                case "Movement__c":
                    return MovementsModel;
                    break;
                default:
                    return null;
            }
        };

    });
