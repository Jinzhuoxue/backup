angular.module('AstraZeneca.Common')
    .service('ImageCacheService', function ($q, $http, ForceClientService, UtilsService) {

        var service = this;

        // User soups are user specific
        var cacheFolderName = "imageChache";
        var fileNameSuffix = "png";

        service.generateFileName = function (imageId) {
            return imageId + "." + fileNameSuffix;
        };

        service.generateCacheFolderName = function () {
            return cordova.file.documentsDirectory;
        };

        service.cacheImageFile = function (imageId, imageURL) {

            //contentURL format : /services/data/v29.0/sobjects/Attachment/00Pc0000002bpaDEAQ/Body
            //console.log(">>>>cacheImageFile:" + imageId + ":" + imageURL);
            var deferred = $q.defer();

            var forceClient = ForceClientService.getForceClient();

            var fileUrl = null;
            var escapedUrl = imageURL.replace('/services/data', '');
            //console.log(">>>>download escapedUrl:" + escapedUrl);

            try {
                forceClient.getChatterFile(escapedUrl, "", function (result) {
                    //console.log("getChatterFile Result:" + result);
                    window.resolveLocalFileSystemURL(service.generateCacheFolderName(), function (dir) {

                        var filename = service.generateFileName(imageId);

                        dir.getFile(filename, {
                            create: true
                        }, function (fileEntry) {

                            fileEntry.createWriter(function (fileWriter) {

                                var blob = new Blob([result]);

                                fileWriter.write(blob);

                                fileUrl = fileEntry.toInternalURL();

                                console.log("cacheImageFile URL:" + fileUrl);
                                deferred.resolve(fileUrl);

                            }, function (error) {
                                console.log("cacheImageFile error:" + error);
                                deferred.reject(error);
                            });

                        }, function (error) {
                            console.log("cacheImageFile error:" + error);
                            deferred.reject(error);
                        });
                    });
                }, function (error) {
                    console.log("getChatterFile Error:" + JSON.stringify(error));
                    deferred.reject(error);
                }, false);
            } catch (e) {
                console.log(">>>cacheImageFile Exception:" + JSON.stringify(error));
            }


            return deferred.promise;
        };

        service.retrieveImage = function (imageId) {

            //console.log(">>>>Retrieve Image file: " + imageId);
            var deferred = $q.defer();

            try {
                var filename = service.generateFileName(imageId);
                var fileUrl = null;
                window.resolveLocalFileSystemURL(service.generateCacheFolderName(), function (dir) {

                    dir.getFile(filename, {
                        create: false
                    }, function (fileEntry) {

                        console.log("Entry:" + fileEntry.toURL());
                        fileEntry.file(function (file) {
                            var reader = new FileReader();

                            reader.onloadend = function (e) {
                                //console.log(">>>readHtmlContent Result ok");
                                deferred.resolve(this.result);
                            };

                            reader.onerror = function (e) {
                                console.log(">>>readHtmlContent Error:" + JSON.stringify(e));
                                deferred.reject(e);
                            }

                            reader.readAsDataURL(file);

                        }, function (error) {
                            console.log(">>>readHtmlContent Error:" + JSON.stringify(error));
                            deferred.reject(error);
                        });

                    }, function (error) {
                        console.log(">>>retrieveImage Error:" + JSON.stringify(error));
                        deferred.reject(error);
                    });
                }, function (error) {
                    console.log(">>>retrieveImage Error:" + JSON.stringify(error));
                    deferred.reject(error);
                });
            } catch (e) {
                console.log(">>>>Retrieve Image Exception: " + e);
            }


            return deferred.promise;
        };


        service.isImageCached = function (imageId) {

            var deferred = $q.defer();

            window.resolveLocalFileSystemURL(service.generateCacheFolderName(), function (fs) {

                function toArray(list) {
                    return Array.prototype.slice.call(list || [], 0);
                }

                //Reading the directory's contents
                var dirReader = fs.createReader();
                var entries = [];

                // Call the reader.readEntries() until no more results are returned.
                var readEntries = function () {
                    dirReader.readEntries(function (results) {
                        if (!results.length) {
                            entries.forEach(function (entry, i) {
                                //console.log("Entry:" + entry.name + ";imageID:" + imageId);

                                if (entry.name.indexOf(imageId) != -1) {
                                    //console.log("Found File:" + entry.toURL());
                                    deferred.resolve(entry.toURL());
                                }
                            });
                            deferred.resolve(null);
                        } else {
                            entries = entries.concat(toArray(results));
                            readEntries();
                        }
                        //deferred.resolve(null);
                    }, function (error) {
                        console.log("readEntries error:" + JSON.stringify(error));
                        deferred.resolve(null);
                    });
                };

                readEntries(); // Start reading dirs.
            }, function (error) {
                console.log("resolveLocalFileSystemURL error:" + JSON.stringify(error));
                deferred.resolve(null);
            });

            return deferred.promise;
        };


    });
