angular.module('AstraZeneca.Common')
    .service('HtmlContentDisplayService', function ($q, $rootScope, UtilsService, HtmlContentModel, ApplicationModel,
        ApplicationService, SmartStoreSyncService, HtmlContentService, IonicLoadingService) {

        var service = this;

        /*
         * Load the content from corresponding html file, file name is "[Id].html"
         * @param retry When retry is true, the function will try to sync the html file again if failed to load.
         */
        service.loadHtmlContent = function (contentId, retry) {

            try {
                var contentURL = cordova.file.documentsDirectory + contentId;
                var contentFileName = contentId + ".html";

                //read the corresponding html file
                HtmlContentService.readHtmlContent(contentFileName, contentURL).then(function (success) {

                    //Use InAppBrowser to open html file
                    var ref = cordova.InAppBrowser.open(contentURL + "/" + contentFileName, '_blank', 'location=no');

                    ref.addEventListener('loadstop', function (event) {
                        HtmlContentModel.fetchByContentId(contentId).then(function (result) {

                            if (result) {
                                result.updated = 0;

                                //console.log("update Html content obj:" + JSON.stringify(obj));
                                HtmlContentModel.upsert(result).then(function (success) {
                                    ApplicationService.updateApplicationUsingSyncResults([{
                                        Id: contentId,
                                        status: 0
                                }]);
                                }, function (error) {
                                    console.log("updateByExtternalId error:" + JSON.stringify(error));
                                });
                            }

                        }, function (error) {
                            console.log("fetchByContentId error:" + JSON.stringify(error));
                        });
                    });

                }, function (error) {

                    console.log("readHtmlContent error:" + JSON.stringify(error));
                    if ($rootScope.online && retry) {
                        IonicLoadingService.show();
                        try {
                            SmartStoreSyncService.startSyncHtmlContent(null, contentId).then(function (result) {
                                IonicLoadingService.hide();
                                if (result.status == 1) {
                                    service.loadHtmlContent(contentId, false);
                                }
                            }, function (error) {
                                IonicLoadingService.hide();
                                UtilsService.showAlert("Sync Error", error.message);
                            }, function (progress) {});
                        } catch (e) {
                            console.log("startSyncSingleNode" + e);
                        }
                    }

                });
            } catch (err) {
                console.log("loadContent exception:" + err);
            }

        };
    });
