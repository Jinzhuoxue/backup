angular.module('AstraZeneca.Common')
    .service('HtmlContentService', function ($q, UtilsService) {

        var service = this;



        service.findHtmlFileInFolder = function (folderPath) {

            var deferred = $q.defer();

            window.resolveLocalFileSystemURL(folderPath, function (fs) {

                function toArray(list) {
                    return Array.prototype.slice.call(list || [], 0);
                }

                //Reading the directory's contents
                var dirReader = fs.createReader();
                var entries = [];

                // Call the reader.readEntries() until no more results are returned.
                var readEntries = function () {
                    dirReader.readEntries(function (results) {
                        if (!results.length) {
                            var isFound = false;
                            entries.forEach(function (entry, i) {
                                console.log("Entry:" + entry.name);

                                if (entry.isFile) {
                                    if (entry.name.indexOf(".html") != -1) {
                                        isFound = true;
                                        console.log("Found HTMl File:" + entry.toURL());
                                        deferred.resolve(entry.toURL());
                                    }
                                }

                            });

                            if (!isFound) {
                                deferred.reject("No html file dound");
                            }
                        } else {
                            console.log("readEntries result count:" + results.length);
                            entries = entries.concat(toArray(results));
                            readEntries();
                        }
                    }, function (error) {
                        console.log("File error:" + error);
                        deferred.reject(error);
                    });
                };

                readEntries(); // Start reading dirs.
            }, function (error) {
                deferred.reject(error);
                console.log("File error:" + error);
            });

            return deferred.promise;
        };


        service.resolveLocalFileURL = function (fileName, folderPath) {
            console.log(">>>>Read HtmlContent file:" + fileName);
            var deferred = $q.defer();
            window.resolveLocalFileSystemURL(folderPath, function (dir) {

                dir.getFile(fileName, {
                    create: false
                }, function (fileEntry) {

                    deferred.resolve(fileEntry.toURL());

                }, function (error) {
                    console.log(">>>readHtmlContent Error:" + JSON.stringify(error));
                    deferred.reject(error);
                });
            }, function (error) {
                console.log(">>>readHtmlContent Error:" + JSON.stringify(error));
                deferred.reject(error);
            });

            return deferred.promise;
        };

        service.readHtmlContent = function (fileName, folderPath) {

            console.log(">>>>Read HtmlContent file: " + folderPath + "/" + fileName);
            var deferred = $q.defer();
            window.resolveLocalFileSystemURL(folderPath, function (dir) {

                dir.getFile(fileName, {
                    create: false
                }, function (fileEntry) {

                    // Get a File object representing the file,
                    // then use FileReader to read its contents.
                    fileEntry.file(function (file) {
                        var reader = new FileReader();

                        reader.onloadend = function (e) {
                            deferred.resolve(this.result);
                        };

                        reader.onerror = function (e) {
                            console.log(">>>readHtmlContent 4 Error:" + JSON.stringify(e));
                            deferred.reject(e);
                        }

                        reader.readAsText(file);

                    }, function (error) {
                        console.log(">>>readHtmlContent 3 Error:" + JSON.stringify(error));
                        deferred.reject(error);
                    });
                }, function (error) {
                    console.log(">>>readHtmlContent 2 Error:" + JSON.stringify(error));
                    deferred.reject(error);
                });
            }, function (error) {
                console.log(">>>readHtmlContent 1 Error:" + JSON.stringify(error));
                deferred.reject(error);
            });

            return deferred.promise;
        };

        service.writeHtmlContent = function (fileName, folderPath, content) {

            console.log(">>>>Write HtmlContent file: " + folderPath + "/" + fileName);

            var deferred = $q.defer();

            window.resolveLocalFileSystemURL(folderPath, function (dir) {

                //var filename = contentId + ".html";
                dir.getFile(fileName, {
                    create: true
                }, function (fileEntry) {

                    fileEntry.createWriter(function (fileWriter) {

                        var blob = new Blob([content], {
                            type: 'text/plain'
                        });

                        fileWriter.write(blob);
                        deferred.resolve(fileWriter.length);

                    }, function (error) {
                        console.log("Write HtmlContent file:" + JSON.stringify(error));
                        deferred.reject(error);
                    });

                }, function (error) {
                    console.log("Write HtmlContent file:" + JSON.stringify(error));
                    deferred.reject(error);
                });
            });
            return deferred.promise;
        };


        service.removeHtmlContent = function (fileName, folderPath) {

            console.log(">>>>Remove HtmlContent file: " + folderPath + "/" + fileName);

            var deferred = $q.defer();
            window.resolveLocalFileSystemURL(folderPath, function (dir) {

                //var filename = contentId + ".html";
                dir.getFile(fileName, {
                    create: false
                }, function (fileEntry) {

                    fileEntry.remove(function () {
                        deferred.resolve(true);
                    }, function (error) {
                        console.log(">>>>Remove HtmlContent remove error:" + JSON.stringify(error));
                        deferred.reject(true);
                    });

                }, function (error) {
                    console.log(">>>>Remove HtmlContent getFile error:" + JSON.stringify(error));
                    if (error.code == FileError.NOT_FOUND_ERR) {
                        deferred.resolve(true);
                    } else {
                        deferred.reject(error);
                    }
                });
            });

            return deferred.promise;

        };

        service.removeDirectory = function (folderPath) {

            console.log(">>>>Remove HtmlContent Directory: " + folderPath);

            var deferred = $q.defer();
            window.resolveLocalFileSystemURL(folderPath, function (dir) {
                dir.removeRecursively(function () {
                    deferred.resolve(true);

                }, function (error) {
                    console.log(">>>>Remove HtmlContent Directory error:" + JSON.stringify(error));
                    if (error.code == FileError.NOT_FOUND_ERR) {
                        deferred.resolve(true);
                    } else {
                        deferred.reject(error);
                    }
                });
            }, function (error) {
                console.log(">>>>Remove HtmlContent Directory error:" + JSON.stringify(error));
                if (error.code == FileError.NOT_FOUND_ERR) {
                    deferred.resolve(true);
                } else {
                    deferred.reject(error);
                }
            });

            return deferred.promise;

        };

        service.removeHtmlLabel = function (text) {
            try {
                var res = text.replace(/<[^>]+>/g, '');
                return res;
            } catch (e) {
                console.log("removeHtmlLabel Exception:" + e);
            }

        };


        service.injectNavibar = function (content) {

            var injectCode = '<div style="height: 96px;background: #9db0ae;display: table;width: 100%;"><div style="display: table-cell;vertical-align: middle; width: 10%;text-align: center;border-right: 1px solid #c0c0c0;"><img style="width:32px" src="./images/backIcon.png" onclick="window.close();return false;"/></div><div style="display: table-cell;vertical-align: middle;width: 80%;" ><div style="padding-left: 5%;"><p>xxxx</p><p>xxxx</p></div></div><div style="display: table-cell;vertical-align: middle;width: 10%;text-align: center;border-left: 1px solid #c0c0c0;" ><img style="width:32px" src="./images/closedIcon.png" onclick="window.close();return false;"/></div></div>';

            var bodyLabelIndex = content.indexOf("<body>");

            if (bodyLabelIndex != -1) {
                var result = content.slice(0, bodyLabelIndex + 6) + injectCode + content.slice(bodyLabelIndex + 6);
                console.log("After Inject Code:" + result);
                return result;
            } else {
                return content;
            }

        };

        service.errorHandler = function (e) {
            var msg = '';

            try {
                switch (e.code) {
                    case FileError.QUOTA_EXCEEDED_ERR:
                        msg = 'QUOTA_EXCEEDED_ERR';
                        break;
                    case FileError.NOT_FOUND_ERR:
                        msg = 'NOT_FOUND_ERR';
                        break;
                    case FileError.SECURITY_ERR:
                        msg = 'SECURITY_ERR';
                        break;
                    case FileError.INVALID_MODIFICATION_ERR:
                        msg = 'INVALID_MODIFICATION_ERR';
                        break;
                    case FileError.INVALID_STATE_ERR:
                        msg = 'INVALID_STATE_ERR';
                        break;
                    default:
                        msg = 'Unknown Error';
                        break;
                };
            } catch (e) {
                console.log("errorHandler exception:" + e);
            }

            return msg;
        };
    });
