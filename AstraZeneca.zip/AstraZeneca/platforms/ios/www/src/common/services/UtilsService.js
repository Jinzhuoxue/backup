angular.module('AstraZeneca.Common')
    .service('UtilsService',
        function ($ionicPopup, $http, $q, ForceClientService) {
            var service = this;

            service.isMobileDevice = function () {
                return !!window.cordova;
            }

            service.objectToArray = function (content) {
                // normalizes data from node and firebase so both get returned as arrays
                if (content.data instanceof Object && !Array.isArray(content.data)) {
                    var newArray = [];

                    for (var key in content.data) {
                        var item = content.data[key];
                        item.id = key;
                        newArray.push(item);
                    }
                    return newArray;

                } else {
                    return content.data;
                }
            };

            service.showConfirm = function (title, text, confirm, cancel) {
                if (cancel === undefined || cancel === null) {
                    cancel = function () {
                        return false
                    }
                }
                var confirmPopup = $ionicPopup.confirm({
                    title: title,
                    template: text
                });
                confirmPopup.then(function (res) {
                    if (res) {
                        confirm(res);
                    } else {
                        cancel();
                    }
                });
            };

            // An alert dialog
            service.showAlert = function (title, text, success) {
                var alertPopup = $ionicPopup.alert({
                    title: title,
                    template: text
                });
                alertPopup.then(function (res) {
                    if (success) {
                        success(res);
                    }
                });
            };

            // cordova dialogs plugin
            service.dialog = function (title, msg, buttonName, callback) {
                if (callback === undefined || callback === null) {
                    callback = function () {
                        console.log('do nothing');
                        //do nothing
                    };
                }
                navigator.notification.alert(msg, callback, title, buttonName);
            };

            service.Result = function (success, message, data) {
                this.success = success;
                this.message = message;
                this.data = data;
            };

            service.isDeviceOnline = function () {

                console.log("device.platform: " + device.platform);
                console.log("ForceClientService.getForceClient().instanceUrl: " + ForceClientService.getForceClient().instanceUrl);

                var deferred = $q.defer();

                // Depending on the device, a few examples are:
                //   - "Android"
                //   - "BlackBerry"
                //   - "iOS"
                //   - "webOS"
                //   - "WinCE"
                //   - "Tizen"
                if (service.isAndroidOs()) {

                    // as navigator.onLine property works for some Android devices, but not all, so we use ping salesforce instead of plugin method.
                    $http.get(ForceClientService.getForceClient().instanceUrl, {
                        timeout: 10000
                    }).then(function (response) {
                        deferred.resolve(true);
                    }, function (response) {
                        deferred.resolve(false);
                    });
                } else {
                    deferred.resolve(cordova.require("com.salesforce.util.bootstrap").deviceIsOnline());
                }

                return deferred.promise;
            };

            service.isAndroidOs = function () {
                return device.platform == "Android";
            };

            service.addLeadings = function (originalStr, length, leadingChar) {
                if (!originalStr) originalStr = "";
                if (!leadingChar) leadingChar = "";
                if (leadingChar.length > 1) leadingChar = leadingChar[0];
                var paddingNubmer = length - originalStr.length;
                if (paddingNubmer < 0) paddingNubmer = 0;
                var leadings = "";
                for (var i = 0; i < paddingNubmer; i++) {
                    leadings += leadingChar;
                }
                return leadings + originalStr;
            };

        }
    );
