angular.module('AstraZeneca.Common')
    .service('ForceClientService', function ($q) {
        var service = this,
            forceClient, userId;

        service.setForceClient = function (instance) {
            forceClient = instance;
        };

        service.getForceClient = function () {
            return forceClient;
        };

        service.setUserId = function (id) {
            userId = id;
        };

        service.getAttachmentBody = function (id) {

            var queryStr = "SELECT Body FROM Attachment WHERE Id ='" + id + "'";

            var deferred = $q.defer();

            forceClient.query(queryStr, function (data) {
                if (data.totalSize == 1) {
                    deferred.resolve(data.records[0].Body);
                } else {
                    deferred.resolve(null);
                }
            }, function (error) {
                alert("error in query: " + JSON.stringify(error));
                deferred.reject(error);
            });

            return deferred.promise;
        };

        service.getUserLanguage = function () {

            var queryStr = "SELECT LanguageLocaleKey,LocaleSidKey FROM User WHERE Id ='" + userId + "'";

            var deferred = $q.defer();

            forceClient.query(queryStr, function (data) {
                if (data.totalSize == 1) {
                    deferred.resolve(data.records[0].LanguageLocaleKey+'&'+data.records[0].LocaleSidKey);
                } else {
                    deferred.resolve(null);
                }
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        };
    });
