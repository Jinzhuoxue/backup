angular.module('AstraZeneca.Common')
    .service('ZipFileService', function ($q, $http, ForceClientService, UtilsService) {

        var service = this;

        service.downloadZipFile = function (contentId, contentURL) {

            //contentURL format : /services/data/v29.0/sobjects/Attachment/00Pc0000002bpaDEAQ/Body
            console.log(">>>>downloadZipFile:" + contentId + ":" + contentURL);
            var deferred = $q.defer();

            var forceClient = ForceClientService.getForceClient();

            var fileUrl = null;
            var escapedUrl = contentURL.replace('/services/data', '');
            console.log(">>>>download escapedUrl:" + escapedUrl);

            forceClient.getChatterFile(escapedUrl, "", function (result) {
                console.log(result);
                window.resolveLocalFileSystemURL(cordova.file.documentsDirectory, function (dir) {

                    var filename = contentId + ".zip";
                    dir.getFile(filename, {
                        create: true
                    }, function (fileEntry) {

                        fileEntry.createWriter(function (fileWriter) {

                            fileWriter.onwriteend = function (e) {
                                fileUrl = fileEntry.toURL();
                                deferred.resolve(fileUrl);
                            };

                            fileWriter.onerror = function (e) {
                                deferred.reject('Write failed: ' + e.toString());
                            };

                            var blob = new Blob([result]);

                            fileWriter.write(blob);

                        }, function (error) {
                            console.log("File error:" + error);
                            deferred.reject(error);
                        });

                    }, function (error) {
                        console.log("File error:" + error);
                        deferred.reject(error);
                    });
                });
            }, function (error) {
                console.log(error);
                deferred.reject(error);
            }, false);

            return deferred.promise;
        };

        /*
         * Unzip file into a specified folder
         * @param fileUrl the source zip file path
         * @param destUrl the full path of destination folder
         */
        service.unzipFile = function (fileUrl, destUrl) {

            var deferred = $q.defer();

            zip.unzip(fileUrl, destUrl, function (result) {
                if (result != -1) {
                    deferred.resolve(result);
                } else {
                    deferred.reject(result);
                }
            }, function (progress) {
                deferred.notify(progress);
            });
            return deferred.promise;
        };


    });
