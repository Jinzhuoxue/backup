angular.module('AstraZeneca.Common')
    .service('ApplicationService', function ($q, UtilsService, ApplicationModel, HtmlContentModel) {

        var service = this;

        var FoundNode = {};
        var LeftNode = {};

        //Global application object
        service.syncProgress = 0;
        service.needReload = 0;
        service.application = null;
        service.contents = null;
        service.currentChapter = null;
        service.currentSubChapter = null;

        service.loadApplication = function () {

            var deferred = $q.defer();
            ApplicationModel.fetchLatestApplication().then(function (result) {
                    if (result != null) {
                        service.application = result;
                        service.contents = result.Nodes;
                        deferred.resolve(service.application);
                    } else {

                        UtilsService.dialog(
                            $filter('translate')('cl.global.lb_message'),
                            $filter('translate')('cl.home.msg_appNotFound'),
                            $filter('translate')('cl.global.btn_ok')
                        );
                        deferred.reject("Failed");
                    }

                },
                function (error) {
                    alert(error);
                });

            return deferred.promise;
        };

        service.setSyncProgress = function (progress) {
            service.syncProgress = progress;
        };

        service.setApplication = function (application) {
            service.application = application;
            service.contents = application.Nodes;
            service.needReload = 1;
        };

        service.getReloadFlag = function () {
            return service.needReload;
        };

        service.setReloadFlag = function (flag) {
            service.needReload = flag;
        };

        service.getApplication = function () {
            return service.application;
        };

        service.getContents = function () {
            return service.contents;
        };

        service.setCurrentChapter = function (chapter) {
            service.currentChapter = chapter;
        };

        service.getCurrentChapter = function () {
            return service.currentChapter;
        };


        service.setCurrentSubChapter = function (chapter) {
            service.currentSubChapter = chapter;
        };

        service.getCurrentSubChapter = function () {
            return service.currentSubChapter;
        };

        /*
         * Find chapter using the specified chapter Id
         * @param chapterId the Id of chapter
         * @return if no Id matched,return null, else return the chapter
         */
        service.findChapterById = function (chapterId) {

            if (!angular.isDefined(chapterId) || service.contents == null) {
                return null;
            }

            for (var i = 0; i < service.contents.length; i++) {
                if (chapterId == service.contents[i].Id) {
                    return service.contents[i];
                }
            }

        };

        /*
         * Find chapter using the specified node Id
         * @param chapterId the Id of chapter
         * @return if no Id matched,return null, else return the chapter
         */
        service.findChapterByNodeId = function (nodeId) {


            if (!angular.isDefined(nodeId) || service.contents == null) {
                return null;
            }

            for (var i = 0; i < service.contents.length; i++) {

                try {
                    service.findNode(service.contents[i], nodeId);
                } catch (exception) {
                    if (exception == FoundNode || exception == LeftNode) {
                        return service.contents[i];
                    }

                    console.log("findChapterByNodeId " + exception);
                }
            }

            return null;

        };


        /*
         * This method is to find node in a node tree. If the specified node is found, a exception will be thrown.
         * @param rootNode the root node of the tree
         * @param subNodeId the Id of the specified node to be found
         * @thrown LeftNode represents a leaf node; FoundNode represents a existed node, not a left node.
         */
        service.findNode = function (rootNode, subNodeId) {

            if (service.isLeftNode(rootNode)) {
                return;
            }

            for (var i = 0; i < rootNode.Nodes.length; i++) {
                var subNode = rootNode.Nodes[i];

                if (subNode.Id == subNodeId) {

                    if (service.isLeftNode(subNode)) {
                        throw LeftNode;
                    } else {
                        throw FoundNode;
                    }
                }

                service.findNode(subNode, subNodeId);
            }

        };

        service.getNode = function (rootNode, subNodeId) {

            if (service.isLeftNode(rootNode)) {
                if (rootNode.Id == subNodeId) {
                    return rootNode;
                } else {
                    return;
                }
            }

            for (var i = 0; i < rootNode.Nodes.length; i++) {
                var subNode = rootNode.Nodes[i];

                if (subNode.Id == subNodeId) {
                    return subNode;
                }

                service.getNode(subNode, subNodeId);
            }

        };


        service.isLeftNodeById = function (nodeId) {


            if (service.application != null) {
                try {
                    service.findNode(service.application, nodeId);
                } catch (exception) {
                    if (exception == LeftNode) {
                        return true;
                    }

                    console.log("findChapterByNodeId " + exception);
                }

                return false;

            } else {
                return false;
            }

        };

        service.isLeftNode = function (node) {
            //rootNode is a left node, check the id if equal the nodeId
            if ((node.Nodes == null || node.Nodes.length == 0) && node.Type === undefined) {
                return true;
            } else {
                return false;
            }
        };

        service.countLeftNodes = function (rootNode) {

            var count = 0;

            if (service.isLeftNode(rootNode)) {
                return 1;
            } else {
                for (var i = 0; i < rootNode.Nodes.length; i++) {
                    var subNode = rootNode.Nodes[i];
                    count += service.countLeftNodes(subNode);
                }

                return count;
            }

        };

        service.countHierarchyNodes = function (rootNode) {

            var count = 0;

            if (service.isLeftNode(rootNode)) {
                return 1;
            } else {
                for (var i = 0; i < rootNode.Nodes.length; i++) {
                    count++;
                    var subNode = rootNode.Nodes[i];
                    count += service.countHierarchyNodes(subNode);
                }

                return count;
            }

        };

        service.retrieveUpdatedFlag = function (rootNode) {


            if (service.isLeftNode(rootNode)) {
                console.log("markUpdatedNode marked:" + rootNode.Id);
                HtmlContentModel.fetchByContentId(rootNode.Id).then(function (result) {
                    if (result != null && result.updated == 1) {
                        rootNode.updated = 1;
                    } else {
                        rootNode.updated = 0;
                    }
                }, function (error) {
                    console.error("fetchByContentId Error:" + JSON.stringify(error));
                });

            } else {
                for (var i = 0; i < rootNode.Nodes.length; i++) {
                    var subNode = rootNode.Nodes[i];
                    service.retrieveUpdatedFlag(subNode);
                }
            }

        };

        service.updateApplicationUsingSyncResults = function (syncResults) {
            function updateUpdatedFlag(result) {

                var nodeId = result.Id;
                var status = result.status;

                //only update the record which status is equal to 1
                if (status === 1) {
                    service.updateUpdatedFlag(service.application, nodeId, status);
                } else {
                    HtmlContentModel.fetchByContentId(nodeId).then(function (result) {
                        if (result != null && result.updated == 1) {
                            service.updateUpdatedFlag(service.application, nodeId, 1);
                        }
                    }, function (error) {
                        console.error("fetchByContentId Error:" + JSON.stringify(error));
                    });
                }

            };

            try {
                if (syncResults && angular.isArray(syncResults)) {
                    angular.forEach(syncResults, updateUpdatedFlag);
                }
            } catch (e) {
                console.log("updateApplicationUsingSyncResults exception:" + e);
            }

        };

        service.updateUpdatedFlag = function (rootNode, nodeId, flag) {

            if (service.isLeftNode(rootNode)) {
                if (rootNode.Id == nodeId) {
                    console.log("updateUpdatedFlag:" + rootNode.Id);
                    rootNode.updated = flag;
                }
                
                return;
            }

            try {
                
                if(rootNode.Nodes == null) return;
                
                var updatedFlag = 0;
                for (var i = 0; i < rootNode.Nodes.length; i++) {
                    var subNode = rootNode.Nodes[i];

                    service.updateUpdatedFlag(subNode, nodeId, flag);

                    if (subNode.updated && subNode.updated == 1) {
                        console.log("updateUpdatedFlag Parent:" + rootNode.Id);
                        updatedFlag = 1;
                    }
                }
                rootNode.updated = updatedFlag;
                
            } catch (e) {
                console.log("updateUpdatedFlag Exception:" + e);
            }


        };

        service.getLeftNodeIDAsList = function (rootNode) {

            var idList = [];

            if (service.isLeftNode(rootNode)) {
                return [rootNode.Id];
            } else {
                for (var i = 0; i < rootNode.Nodes.length; i++) {
                    var subNode = rootNode.Nodes[i];
                    idList = service.getLeftNodeIDAsList(subNode).concat(idList);
                }

                return idList;
            }

        };

        service.readNodePath = function (rootNode, nodeId) {

            //Verify params
            if (angular.isUndefined(rootNode) || angular.isUndefined(nodeId)) {
                return null;
            }

            //process left node
            if (service.isLeftNode(rootNode)) {
                if (nodeId == rootNode.Id) {
                    return rootNode.Name;
                } else {
                    return null;
                }
            } else {
                for (var i = 0; i < rootNode.Nodes.length; i++) {
                    var subNode = rootNode.Nodes[i];

                    //If the node is not found,result will be null
                    result = service.readNodePath(subNode, nodeId);

                    if (result) {
                        if (service.isLeftNode(subNode)) {
                            return result;
                        } else {
                            return subNode.Name + " / " + result;
                        }
                    }
                }
            }


            return null;
        };
        /*
         * Generate the full path title of a left node
         * @param nodeId the Id of left node
         * @return title (format:[Chapter Order] [Chapter Name]/[Sub Chapter Name]/[Section Name]/.../[Section Name])
         */
        service.generateLeftNodeTitle = function (nodeId) {

            if (angular.isUndefined(service.application)) return null;

            var chapter = service.findChapterByNodeId(nodeId);
            if (chapter) {

                var nodePath = service.readNodePath(chapter, nodeId);

                return chapter.Order + " " + chapter.Name + " / " + nodePath;

            } else {
                return null;
            }
        };

        service.setCurrentSubChapterById = function (nodeId) {

            console.log("findChapterByNodeId In");
            if (!angular.isDefined(nodeId) || service.contents == null) {
                console.log("findChapterByNodeId NUll");
                return false;
            }

            //Iterated each main chapter node
            for (var i = 0; i < service.contents.length; i++) {

                //sub chapter Node
                var subChapters = service.contents[i].Nodes;

                for (var j = 0; j < subChapters.length; j++) {
                    //If this sub chapter's id is equal to nodeId
                    if (subChapters[j].Id == nodeId) {
                        console.log("setCurrentSubChapterById " + nodeId);
                        service.setCurrentSubChapter(subChapters[j]);
                        return true;
                    } else {
                        try {
                            service.findNode(subChapters[j], nodeId);
                        } catch (exception) {
                            if (exception == FoundNode) {
                                service.setCurrentSubChapter(subChapters[j]);
                                console.log("setCurrentSubChapterById by Section:" + JSON.stringify(subChapters[j]));
                                return true;
                            }

                            console.log("setCurrentSubChapterById " + exception);
                        }
                    }

                }
            }
            console.log("findChapterByNodeId NUll");

            return false;

        };

    });
