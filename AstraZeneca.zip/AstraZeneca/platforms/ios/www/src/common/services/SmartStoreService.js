angular.module('AstraZeneca.Common')
    .service('SmartStoreService', function ($q, SMARTSTORE_SOUP_STATUS) {
    	var service = this;
    
        // User soups are user specific
        var soupSettings = [
            {
                name: "HtmlContent", 
                indexSpec: [
                    {"path": "Id", "type": "string"},
                    {"path": "content", "type": "full_text"},
                    {"path": "lastSyncDown", "type": "string"}
                ]
            },
            {
                name: "Application", 
                indexSpec: [
                    {"path": "Id", "type": "string"},
                    {"path": "Language", "type": "string"}
                ]
            }
        ];


        /**
         * Setup user specific soups
         */
        service.registerSoups = function () {

	        var promises = [];

            _.each(soupSettings, function (soupInfo, index) {
                promises.push(registerSoup(false, soupInfo.name, soupInfo.indexSpec));
            });

            return $q.all(promises);
	    };

	    var registerSoup = function (isGlobal, soupName, indexSpec) {
	    	var deferred = $q.defer();

	        navigator.smartstore.soupExists(isGlobal, soupName, function (exists) {

	        	// Initialize soup if not existing
	            if (!exists) {
	                console.log(">>>> creating soup for " + soupName);

	                navigator.smartstore.registerSoup(isGlobal, soupName, indexSpec, function (param) {
	                    console.log('>>>> soup created: ' + soupName);
	                }, function (error) {
	                    console.log(error);
	                });

	                deferred.resolve(SMARTSTORE_SOUP_STATUS.SOUP_CREATED);
	            } else {
	                console.log(">>>> soup already exist: " + soupName);
	                deferred.resolve(SMARTSTORE_SOUP_STATUS.SOUP_EXIST);
	            }
	        }, function (error) {
	            alert("Error while initializing soup: " + soupName + " - " + error);
	            deferred.reject(error);
	        });

	        return deferred.promise;
	    }

	    /**
         * show standard soup inspector
         */
        service.showInspector = function () {
            cordova.require("com.salesforce.plugin.smartstore").showInspector();
        };
    })

	.constant("SMARTSTORE_SOUP_STATUS", {
		SOUP_CREATED: "SOUP_CREATED",
		SOUP_EXIST: "SOUP_EXIST"
	})
;
