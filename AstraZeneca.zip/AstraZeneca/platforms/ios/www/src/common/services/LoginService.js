angular.module('AstraZeneca.Common')
    .service('LoginService', function ($q, ForceClientService, UtilsService, md5) {
        var service = this;

        // OAuth Configuration
        var loginUrl = 'https://azusgb01--fEISOP.cs14.my.salesforce.com';
        var clientId = '3MVG9rKhT8ocoxGk7PVNrcWdsEHxVh6Yj65JBUYqh9IMYkqI2.19EG0Paa603iMDaS8V4nzbb9jBW9igT5.Q5';
        var redirectUri = 'http://localhost:8080/oauthcallback.html';
        var proxyUrl = 'http://localhost:8080/proxy.php?mode=native';

        // OAuth for login in device via cordova plugin
        service.oauthViaDevicePlugin = function (callback) {

            // Get salesforce mobile sdk OAuth plugin
            var oauthPlugin = cordova.require("com.salesforce.plugin.oauth");

            // Call getAuthCredentials to get the initial session credentials
            oauthPlugin.getAuthCredentials(

                // Callback method when authentication succeeds.
                // console.log("in getAuthCredentials");
                function (creds) {
                    // Create forcetk client instance for rest API calls
                    console.log(">>>> creds: " + JSON.stringify(creds));
                    var userId = creds.userId;
                    var forceClient = new forcetk.Client(creds.clientId, creds.loginUrl, null);
                    //forceClient.forceClient
                    forceClient.setSessionToken(creds.accessToken, "v33.0", creds.instanceUrl);
                    forceClient.setRefreshToken(creds.refreshToken);
                    forceClient.setUserAgentString(creds.userAgent);

                    console.log(">>>> forceClient: " + JSON.stringify(forceClient));
                    ForceClientService.setForceClient(forceClient);
                    ForceClientService.setUserId(userId);

                    if (callback) callback();
                },
                function (error) {
                    alert('Failed to authenticate user: ' + error);
                }
            );
        };



        service.logout = function () {
            // TODO: delete local user from global soup
            //service.removeLocalUser(LocalDataService.get("currentUser").username).then(function () {
            cordova.require("com.salesforce.plugin.sfaccountmanager").logout();
            //});
        };


    });
