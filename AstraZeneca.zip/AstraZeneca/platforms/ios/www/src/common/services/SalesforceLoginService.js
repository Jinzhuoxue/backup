angular.module('AstraZeneca.Common')
    .service('SalesforceLoginService', function ($q,$http,ForceClientService) {
        var service = this;

        service.webLogin = function () {
            var deferred = $q.defer();

            var forceClient = ForceClientService.getForceClient();

            var url = forceClient.instanceUrl + '/secur/frontdoor.jsp?sid=' + forceClient.sessionId;

            $http.get(url).then(function () {
                console.log('>>>> frontdoor login success');
                deferred.resolve();
            });

            return deferred.promise;
        };
    });
