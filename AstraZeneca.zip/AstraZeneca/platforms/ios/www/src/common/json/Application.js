{
    "Id": "rootId",
    "Language": "en-US",
    "Name": "EI SOP User Portal",
    "Description": "Lokale SOP zur Globalen Richtlinie für Ethische Interaktionen",
    "SplashScreen": "src/assets/img/splash.png",
    "Nodes": [
        {
            "Id": "mainC1",
            "Name": "Chapter One",
            "Parent": "rootId",
            "Order": "1",
            "Main_Picture": "",
            "Main_Colour": "#778899",
            "Nodes": [
                {
                    "Id": "subC1",
                    "Name": "Sub Chapter One",
                    "Parent": "mainC1",
                    "Order": "1",
                    "Nodes": [
                        {
                            "Id": "Section1",
                            "Name": "Section1",
                            "Parent": "subC1",
                            "Order": "1",
                            "Nodes": [
                                {
                                    "Id": "SubSection1",
                                    "Name": "Sub Section1",
                                    "Parent": "Section1",
                                    "Order": "1",
                                    "Nodes": [
                                        {
                                            "Id": "SubSubSection1",
                                            "Name": "Sub Sub Section1",
                                            "Parent": "SubSection1",
                                            "Order": "1",
                                            "Nodes": []
                                        },
                                        {
                                            "Id": "SubSubSection2",
                                            "Name": "Sub Sub Section2",
                                            "Parent": "SubSection1",
                                            "Order": "2",
                                            "Nodes": []
                                        },
                                        {
                                            "Id": "SubSubSection3",
                                            "Name": "Sub Sub Section3",
                                            "Parent": "SubSection1",
                                            "Order": "3",
                                            "Nodes": []
                                        }
                                    ]
                                },
                                {
                                    "Id": "SubSection2",
                                    "Name": "Sub Section2",
                                    "Parent": "Section1",
                                    "Order": "2",
                                    "Nodes": []
                                },
                                {
                                    "Id": "SubSection3",
                                    "Name": "Sub Section3",
                                    "Parent": "Section1",
                                    "Order": "3",
                                    "Nodes": []
                                }
                            ]
                        },
                        {
                            "Id": "Section2",
                            "Name": "Section2",
                            "Parent": "subC1",
                            "Order": "1",
                            "Nodes": []
                        },
                        {
                            "Id": "Section3",
                            "Name": "Section3",
                            "Parent": "subC1",
                            "Order": "1",
                            "Nodes": []
                        },
                        {
                            "Id": "Section4",
                            "Name": "Section4",
                            "Parent": "subC1",
                            "Order": "1",
                            "Nodes": []
                        }

                    ]
                },
                {
                    "Id": "sub C2",
                    "Name": "Sub Chapter 2",
                    "Parent": "mainC1",
                    "Order": "2",
                    "Nodes": []
                },
                {
                    "Id": "sub C3",
                    "Name": "Sub Chapter 3",
                    "Parent": "mainC1",
                    "Order": "3",
                    "Nodes": []
                    },
                {
                    "Id": "sub C4",
                    "Name": "Sub Chapter 4",
                    "Parent": "mainC1",
                    "Order": "4",
                    "Nodes": []
                    }
                ]
            },
        {
            "Id": "mainC2",
            "Name": "Chapter Two",
            "Parent": "rootId",
            "Order": "2",
            "Main_Picture": "",
            "Main_Colour": "#9ACD32",
            "Nodes": [
                {
                    "Id": "sub C1",
                    "Name": "Sub Chapter One",
                    "Parent": "mainC2",
                    "Order": "1",
                    "Nodes": []
                    },
                {
                    "Id": "sub C2",
                    "Name": "Sub Chapter 2",
                    "Parent": "mainC2",
                    "Order": "2",
                    "Nodes": []
                },
                {
                    "Id": "sub C3",
                    "Name": "Sub Chapter 3",
                    "Parent": "mainC2",
                    "Order": "3",
                    "Nodes": []
                    },
                {
                    "Id": "sub C4",
                    "Name": "Sub Chapter 4",
                    "Parent": "mainC2",
                    "Order": "4",
                    "Nodes": []
                    }
                ]
            },
        {
            "Id": "mainC3",
            "Name": "Chapter Three",
            "Parent": "rootId",
            "Order": "3",
            "Main_Picture": "",
            "Main_Colour": "#FF8C00",
            "Nodes": [
                {
                    "Id": "sub C1",
                    "Name": "Sub Chapter One",
                    "Parent": "mainC3",
                    "Order": "1",
                    "Nodes": []
                    },
                {
                    "Id": "sub C2",
                    "Name": "Sub Chapter 2",
                    "Parent": "mainC3",
                    "Order": "2",
                    "Nodes": []
                },
                {
                    "Id": "sub C3",
                    "Name": "Sub Chapter 3",
                    "Parent": "mainC3",
                    "Order": "3",
                    "Nodes": []
                    },
                {
                    "Id": "sub C4",
                    "Name": "Sub Chapter 4",
                    "Parent": "mainC3",
                    "Order": "4",
                    "Nodes": []
                    }
                ]
            },
        {
            "Id": "mainC4",
            "Name": "Chapter Four",
            "Parent": "rootId",
            "Order": "4",
            "Main_Picture": "",
            "Main_Colour": "#696969",
            "Nodes": [
                {
                    "Id": "sub C1",
                    "Name": "Sub Chapter One",
                    "Parent": "mainC4",
                    "Order": "1",
                    "Nodes": []
                    },
                {
                    "Id": "sub C2",
                    "Name": "Sub Chapter 2",
                    "Parent": "mainC4",
                    "Order": "2",
                    "Nodes": []
                },
                {
                    "Id": "sub C3",
                    "Name": "Sub Chapter 3",
                    "Parent": "mainC4",
                    "Order": "3",
                    "Nodes": []
                    },
                {
                    "Id": "sub C4",
                    "Name": "Sub Chapter 4",
                    "Parent": "mainC4",
                    "Order": "4",
                    "Nodes": []
                    }
                ]
            }
    ]

}
